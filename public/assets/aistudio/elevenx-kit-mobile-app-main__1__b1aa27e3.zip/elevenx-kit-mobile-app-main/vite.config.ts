// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { loadEnv } from "vite";

const env = {
  ...loadEnv("development", process.cwd(), ""),
  ...loadEnv("production", process.cwd(), ""),
};

export default defineConfig({
  vite: {
    define: Object.fromEntries([
      "API_KEY",
      "AUTH_DOMAIN",
      "PROJECT_ID",
      "STORAGE_BUCKET",
      "MESSAGING_SENDER_ID",
      "APP_ID",
    ].map((name) => [`import.meta.env.NEXT_PUBLIC_FIREBASE_${name}`, JSON.stringify(env[`NEXT_PUBLIC_FIREBASE_${name}`] ?? "")])),
    server: {
      allowedHosts: true,
    },
  },
  tanstackStart: {
    server: { entry: "server" },
  },
});
