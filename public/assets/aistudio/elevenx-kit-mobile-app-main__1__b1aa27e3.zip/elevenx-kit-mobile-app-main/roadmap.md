# Roadmap
- [x] Accounts: customer, admin, rider sign-in; rider applications + approval; super admin manages admins
- [ ] Move products, orders, deliveries into Lovable Cloud with photo uploads (riders see only assigned orders)
- [ ] Video stadium homepage hero
- [ ] Checkout with address + delivery fees
- [ ] Relworx payments — blocked: needs merchant keys
- [ ] Notifications (customers, admins, riders)
