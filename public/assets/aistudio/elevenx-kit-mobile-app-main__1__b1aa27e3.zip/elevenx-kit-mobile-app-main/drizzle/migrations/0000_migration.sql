create type public.app_role as enum ('super_admin', 'admin', 'rider');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text not null default '',
  phone text not null default '',
  address text not null default '',
  city text not null default 'Kampala',
  created_at timestamptz not null default now()
);
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select, insert, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id or public.has_role(auth.uid(), 'admin'));
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "read own or admin" on public.user_roles for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "super admin grants admin" on public.user_roles for insert to authenticated with check (
  (role = 'admin' and public.has_role(auth.uid(), 'super_admin')) or (role = 'rider' and public.has_role(auth.uid(), 'admin')));
create policy "super admin removes admin" on public.user_roles for delete to authenticated using (
  (role = 'admin' and public.has_role(auth.uid(), 'super_admin') and user_id <> auth.uid()) or (role = 'rider' and public.has_role(auth.uid(), 'admin')));

create table public.rider_applications (
  user_id uuid primary key,
  full_name text not null,
  phone text not null,
  area text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
grant select, insert, update on public.rider_applications to authenticated;
grant all on public.rider_applications to service_role;
alter table public.rider_applications enable row level security;
create policy "apply as self" on public.rider_applications for insert to authenticated with check (auth.uid() = user_id and status = 'pending');
create policy "read own or admin" on public.rider_applications for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "admin decides" on public.rider_applications for update to authenticated using (public.has_role(auth.uid(), 'admin'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''));
  if lower(new.email) = 'vicentmukisa156@gmail.com' then
    insert into public.user_roles (user_id, role) values (new.id, 'super_admin'), (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();