
create table public.products (
  id bigserial primary key, name text not null, team text not null default '', category text not null default 'Club',
  price integer not null check (price >= 0), sizes text[] not null default '{S,M,L,XL}', stock integer not null default 0 check (stock >= 0),
  image text not null default '', active boolean not null default true, created_at timestamptz not null default now()
);
create table public.delivery_zones (
  id bigserial primary key, name text not null unique, fee integer not null default 0 check (fee >= 0), eta text not null default '', active boolean not null default true
);
create table public.orders (
  id text primary key default ('EX' || to_char(now(),'YYMMDD') || lpad((floor(random()*100000))::text,5,'0')),
  user_id uuid not null, customer_name text not null default '', phone text not null default '', address text not null default '',
  zone text not null default '', subtotal integer not null default 0, delivery_fee integer not null default 0, total integer not null default 0,
  status text not null default 'Pending payment', rider_id uuid, delivery_status text not null default 'Unassigned',
  created_at timestamptz not null default now()
);
create table public.order_items (
  id bigserial primary key, order_id text not null references public.orders(id) on delete cascade, product_id bigint,
  name text not null, size text not null, qty integer not null check (qty > 0), price integer not null, image text not null default ''
);
create index on public.orders(user_id); create index on public.orders(rider_id); create index on public.order_items(order_id);

grant select on public.products, public.delivery_zones to anon, authenticated;
grant insert, update, delete on public.products, public.delivery_zones to authenticated;
grant select, update on public.orders to authenticated;
grant select on public.order_items to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant all on public.products, public.delivery_zones, public.orders, public.order_items to service_role;

alter table public.products enable row level security;
alter table public.delivery_zones enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "Anyone sees active products" on public.products for select to anon, authenticated using (active or public.has_role(auth.uid(),'admin'));
create policy "Admins manage products" on public.products for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "Anyone sees zones" on public.delivery_zones for select to anon, authenticated using (true);
create policy "Admins manage zones" on public.delivery_zones for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create policy "Read own, assigned or all orders" on public.orders for select to authenticated
  using (user_id = auth.uid() or rider_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "Admins update orders" on public.orders for update to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "Read items of visible orders" on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or o.rider_id = auth.uid() or public.has_role(auth.uid(),'admin'))));

-- Customers place orders only through this function: prices and photos come from the catalogue, not the browser.
create or replace function public.place_order(_items jsonb, _name text, _phone text, _address text, _zone text)
returns text language plpgsql security definer set search_path = public as $$
declare _oid text; _sub integer := 0; _fee integer; it jsonb; p public.products;
begin
  if auth.uid() is null then raise exception 'Sign in to place an order'; end if;
  if jsonb_array_length(coalesce(_items,'[]'::jsonb)) = 0 then raise exception 'Cart is empty'; end if;
  if coalesce(trim(_phone),'') = '' or coalesce(trim(_address),'') = '' then raise exception 'Phone and address are required'; end if;
  select fee into _fee from public.delivery_zones where name = _zone and active;
  if _fee is null then raise exception 'Choose a delivery area we cover'; end if;
  insert into public.orders(user_id, customer_name, phone, address, zone, delivery_fee)
    values (auth.uid(), left(_name,120), left(_phone,40), left(_address,300), _zone, _fee) returning id into _oid;
  for it in select * from jsonb_array_elements(_items) loop
    select * into p from public.products where id = (it->>'product_id')::bigint and active;
    if p.id is null then raise exception 'A jersey in your cart is no longer available'; end if;
    if (it->>'qty')::int < 1 or (it->>'qty')::int > 20 then raise exception 'Invalid quantity'; end if;
    if p.stock < (it->>'qty')::int then raise exception '% is out of stock', p.name; end if;
    insert into public.order_items(order_id, product_id, name, size, qty, price, image)
      values (_oid, p.id, p.name, left(it->>'size',8), (it->>'qty')::int, p.price, p.image);
    update public.products set stock = stock - (it->>'qty')::int where id = p.id;
    _sub := _sub + p.price * (it->>'qty')::int;
  end loop;
  update public.orders set subtotal = _sub, total = _sub + _fee where id = _oid;
  return _oid;
end $$;
revoke execute on function public.place_order(jsonb,text,text,text,text) from public, anon;
grant execute on function public.place_order(jsonb,text,text,text,text) to authenticated;

-- Riders may only change the delivery progress of orders assigned to them.
create or replace function public.rider_update_delivery(_order_id text, _status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if _status not in ('Accepted','Picked up','On the way','Delivered','Failed delivery') then raise exception 'Invalid status'; end if;
  update public.orders set delivery_status = _status,
    status = case when _status = 'Delivered' then 'Delivered' when _status in ('Picked up','On the way') then 'Out for delivery' else status end
  where id = _order_id and rider_id = auth.uid() and public.has_role(auth.uid(),'rider');
  if not found then raise exception 'Not your delivery'; end if;
end $$;
revoke execute on function public.rider_update_delivery(text,text) from public, anon;
grant execute on function public.rider_update_delivery(text,text) to authenticated;

-- Admins need rider names for assignment.
create policy "Riders' profiles visible to admins already; riders see customers of assigned orders" on public.profiles for select to authenticated
  using (exists (select 1 from public.orders o where o.user_id = profiles.id and o.rider_id = auth.uid()));

create policy "Anyone views product photos" on storage.objects for select to anon, authenticated using (bucket_id = 'product-images');
create policy "Admins upload product photos" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.has_role(auth.uid(),'admin'));
create policy "Admins change product photos" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.has_role(auth.uid(),'admin'));

insert into public.products(name, team, category, price, sizes, stock, image) values
 ('Arsenal Home Jersey','Arsenal','Club',85000,'{S,M,L,XL,XXL}',12,'asset:arsenal'),
 ('Uganda Cranes Home Jersey','Uganda Cranes','National',75000,'{S,M,L,XL}',8,'asset:uganda'),
 ('Manchester United Jersey','Manchester United','Club',90000,'{S,M,L,XL,XXL}',6,'asset:manutd'),
 ('Real Madrid Away Jersey','Real Madrid','Club',95000,'{S,M,L,XL}',10,'asset:realmadrid'),
 ('Nigeria National Jersey','Nigeria','National',80000,'{S,M,L,XL}',5,'asset:nigeria');
insert into public.delivery_zones(name, fee, eta) values ('Kampala Central',5000,'Same day'),('Wakiso',8000,'1–2 days');
