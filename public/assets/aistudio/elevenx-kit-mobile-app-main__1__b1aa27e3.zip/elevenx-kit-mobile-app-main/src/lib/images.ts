import { supabase } from "@/integrations/supabase/client";
import arsenal from "@/assets/jersey-arsenal.jpg";
import uganda from "@/assets/jersey-uganda.jpg";
import manutd from "@/assets/jersey-manutd.jpg";
import realmadrid from "@/assets/jersey-realmadrid.jpg";
import nigeria from "@/assets/jersey-nigeria.jpg";

/** Product image refs: "asset:<key>" = bundled photo, http(s) URL = as-is, anything else = path in the product-images storage bucket. */
const assets: Record<string, string> = { arsenal, uganda, manutd, realmadrid, nigeria };
export const BUCKET = "product-images";
const cache = new Map<string, Promise<string | undefined>>();

export function resolveImage(ref?: string | null): Promise<string | undefined> {
  if (!ref) return Promise.resolve(undefined);
  if (ref.startsWith("asset:")) return Promise.resolve(assets[ref.slice(6)]);
  if (/^(https?:|data:|blob:|\/)/.test(ref)) return Promise.resolve(ref);
  let p = cache.get(ref);
  if (!p) {
    p = supabase.storage.from(BUCKET).createSignedUrl(ref, 60 * 60 * 24 * 7).then(({ data }) => data?.signedUrl);
    cache.set(ref, p);
  }
  return p;
}

/** Synchronous answer when no network lookup is needed (avoids a loading flash). */
export function resolveImageSync(ref?: string | null): string | undefined | null {
  if (!ref) return undefined;
  if (ref.startsWith("asset:")) return assets[ref.slice(6)];
  if (/^(https?:|data:|blob:|\/)/.test(ref)) return ref;
  return null;
}
