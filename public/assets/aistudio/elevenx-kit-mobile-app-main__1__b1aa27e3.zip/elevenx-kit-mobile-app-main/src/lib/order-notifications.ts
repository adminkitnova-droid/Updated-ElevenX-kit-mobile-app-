export async function publishOrderNotification(input: { token: string; title: string; body: string; orderId: string }) {
  return fetch("/api/notifications/publish", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ ...input, audience: "all" }),
  });
}
