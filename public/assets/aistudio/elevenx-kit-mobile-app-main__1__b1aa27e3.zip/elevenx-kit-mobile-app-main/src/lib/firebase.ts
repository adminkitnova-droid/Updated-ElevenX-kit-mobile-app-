import { collection, collectionGroup, doc, getDocs, getFirestore, limit, onSnapshot, orderBy, query, setDoc, Timestamp, where } from "firebase/firestore"
import { getAuth } from "firebase/auth"
import { getDownloadURL, getStorage, ref as storageRef, uploadBytes } from "firebase/storage"
import { getApp, getApps, initializeApp } from "firebase/app"

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY ?? import.meta.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? import.meta.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID ?? import.meta.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ?? import.meta.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? import.meta.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? import.meta.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

export function getFirebaseApp() {
  if (!config.apiKey || !config.projectId) return null
  return getApps().length ? getApp() : initializeApp(config)
}

export function getFirebaseAuth() {
  const app = getFirebaseApp()
  return app ? getAuth(app) : null
}

function getFirebaseDb() {
  const app = getFirebaseApp()
  return app ? getFirestore(app) : null
}

export type FirebaseProduct = {
  id: string
  name: string
  price: number
  image: string
  frontImage?: string
  backImage?: string
  category?: string
  description?: string
}

export type FirebaseDesignRecord = Record<string, unknown> & { id?: number; productId?: number; productImage?: string; formatVersion?: "customization.v1" }

function userCollection(userId: string, name: string) {
  const db = getFirebaseDb()
  return db ? collection(db, "users", userId, name) : null
}

export async function saveFirebaseDesign(userId: string, design: FirebaseDesignRecord) {
  const designs = userCollection(userId, "designs")
  if (!designs) return null
  const reference = doc(designs, String(design.id ?? crypto.randomUUID()))
  await setDoc(reference, { ...design, id: reference.id, updatedAt: Timestamp.now() }, { merge: true })
  return reference.id
}

export async function fetchFirebaseDesigns(userId: string): Promise<FirebaseDesignRecord[]> {
  const designs = userCollection(userId, "designs")
  if (!designs) return []
  const snapshot = await getDocs(query(designs, orderBy("updatedAt", "desc"), limit(20)))
  return snapshot.docs.map((item) => ({ id: item.id, ...item.data() }))
}

export async function saveFirebaseCart(userId: string, cart: unknown[]) {
  const carts = userCollection(userId, "cart")
  if (!carts) return
  await setDoc(doc(carts, "current"), { items: cart, updatedAt: Timestamp.now() }, { merge: true })
}

export async function createFirebaseOrder(userId: string, order: Record<string, unknown>) {
  const orders = userCollection(userId, "orders")
  if (!orders) return null
  const reference = doc(orders)
  await setDoc(reference, { ...order, id: reference.id, userId, createdAt: Timestamp.now() })
  return reference.id
}

export function subscribeToFirebaseRiderOrders(userId: string, onChange: (orders: Record<string, unknown>[]) => void) {
  const db = getFirebaseDb()
  if (!db) return () => undefined
  const orders = query(collectionGroup(db, "orders"), where("riderId", "==", userId), orderBy("createdAt", "desc"))
  return onSnapshot(orders, (snapshot) => onChange(snapshot.docs.map((item) => ({ id: item.id, ...item.data() }))))
}

export async function fetchFirebaseOrders(userId: string): Promise<Record<string, unknown>[]> {
  const orders = userCollection(userId, "orders")
  if (!orders) return []
  const snapshot = await getDocs(query(orders, orderBy("createdAt", "desc"), limit(50)))
  return snapshot.docs.map((item) => ({ id: item.id, ...item.data() }))
}

export async function uploadFirebaseProductImage(file: File) {
  const app = getFirebaseApp()
  if (!app) return null
  const reference = storageRef(getStorage(app), `products/${crypto.randomUUID()}-${file.name}`)
  const result = await uploadBytes(reference, file, { contentType: file.type })
  return getDownloadURL(result.ref)
}

export type FirebaseHeroSettings = { videoUrl?: string; title?: string; subtitle?: string; ctaLabel?: string; ctaUrl?: string };

export async function fetchFirebaseHeroSettings(): Promise<FirebaseHeroSettings> {
  const db = getFirebaseDb();
  if (!db) return {};
  const snapshot = await getDocs(collection(db, "siteSettings"));
  const item = snapshot.docs.find((entry) => entry.id === "hero");
  return (item?.data() ?? {}) as FirebaseHeroSettings;
}

export async function saveFirebaseHeroSettings(settings: FirebaseHeroSettings) {
  const db = getFirebaseDb();
  if (!db) return null;
  await setDoc(doc(db, "siteSettings", "hero"), { ...settings, updatedAt: Timestamp.now() }, { merge: true });
  return "hero";
}

export async function uploadFirebaseHeroAsset(file: File) {
  const app = getFirebaseApp();
  if (!app) return null;
  const reference = storageRef(getStorage(app), `site/hero/${crypto.randomUUID()}-${file.name}`);
  const result = await uploadBytes(reference, file, { contentType: file.type });
  return getDownloadURL(result.ref);
}

export async function saveFirebaseProduct(product: Record<string, unknown>) {
  const db = getFirebaseDb()
  if (!db) return null
  const id = String(product.id ?? crypto.randomUUID())
  await setDoc(doc(db, "products", id), { ...product, id, updatedAt: Timestamp.now() }, { merge: true })
  return id
}

export async function fetchFirebaseProducts(): Promise<FirebaseProduct[]> {
  const db = getFirebaseDb()
  if (!db) return []

  const snapshot = await getDocs(collection(db, "products"))
  return snapshot.docs
    .map((item) => {
      const value = item.data() as Record<string, unknown>
      const image = String(value.imageUrl ?? value.image ?? value.photoURL ?? "")
      if (!image) return null
      return {
        id: String(value.productId ?? value.id ?? item.id),
        name: String(value.name ?? value.title ?? "Jersey"),
        price: Number(value.price ?? 0),
        image,
        frontImage: value.frontImageUrl ? String(value.frontImageUrl) : image,
        backImage: value.backImageUrl ? String(value.backImageUrl) : image,
        category: value.category ? String(value.category) : undefined,
        description: value.description ? String(value.description) : undefined,
      }
    })
    .filter((item): item is FirebaseProduct => item !== null)
}
