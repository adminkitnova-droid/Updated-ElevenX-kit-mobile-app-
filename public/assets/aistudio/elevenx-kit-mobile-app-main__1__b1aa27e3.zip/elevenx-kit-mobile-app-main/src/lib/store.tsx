import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { createFirebaseOrder, fetchFirebaseDesigns, fetchFirebaseOrders, fetchFirebaseProducts, saveFirebaseCart, saveFirebaseDesign } from "@/lib/firebase";
const arsenalImage = "/jersey-arsenal.jpg";
const manutdImage = "/jersey-manutd.jpg";
const nigeriaImage = "/jersey-nigeria.jpg";
const realMadridImage = "/jersey-realmadrid.jpg";
const ugandaImage = "/jersey-uganda.jpg";
const imageAliases: Record<string, string> = {
  "asset:arsenal": arsenalImage,
  "asset:manutd": manutdImage,
  "asset:nigeria": nigeriaImage,
  "asset:realmadrid": realMadridImage,
  "asset:uganda": ugandaImage,
};
const resolveProductImage = (image: string) => imageAliases[image] ?? image;

export type Product = { id: number; name: string; team: string; category: string; price: number; size: string[]; stock: number; image: string; frontImage?: string; backImage?: string; active?: boolean };
export type CartItem = { product: Product; qty: number; size: string; image: string; customization?: Design };
export type OrderItem = { productId: number; name: string; size: string; qty: number; price: number; image: string; customization?: Design };
export type Order = {
  id: string; date: string; total: number; subtotal: number; deliveryFee: number; status: string; deliveryStatus: string;
  customerName: string; phone: string; address: string; zone: string; riderId: string | null; userId: string; items: OrderItem[];
};
export type Zone = { id: number; name: string; fee: number; eta: string; active: boolean };
export type Design = { mode: string; jersey: string; name: string; number: string; tag: string; textColor: string; bodyColor: string; sleeveColor: string; collarColor: string; pattern: string; font: string; fontSize: number; artwork: string; artworkImage: string; artworkX: number; artworkY: number; artworkScale: number; side: string; formatVersion?: "customization.v1"; productId?: number; productImage?: string; frontImage?: string; backImage?: string; id?: number };
export type CheckoutDetails = { name: string; phone: string; address: string; zone: string; destination?: { lat: number; lon: number; label: string }; distanceKm?: number; deliveryFee?: number };

export const defaultDesign = (): Design => ({ mode: "Basic", jersey: "Arsenal", name: "", number: "10", tag: "", textColor: "#ffffff", bodyColor: "#b8202e", sleeveColor: "#b8202e", collarColor: "#ffffff", pattern: "Plain", font: "Arial", fontSize: 64, artwork: "", artworkImage: "", artworkX: 50, artworkY: 42, artworkScale: 1, side: "Back" });

/** Saved in this browser only: cart, favourites, recently viewed, Studio designs. Catalogue and orders live in Lovable Cloud. */
type Local = { cart: CartItem[]; favourites: number[]; viewed: number[]; savedDesigns: Design[]; studio: Design };
const initial = (): Local => ({ cart: [], favourites: [], viewed: [], savedDesigns: [], studio: defaultDesign() });

const KEY = "elevenx-demo";
export const money = (n: number) => "UGX " + Number(n || 0).toLocaleString("en-UG");

export function cartTotals(cart: CartItem[]) {
  return { count: cart.reduce((s, x) => s + x.qty, 0), total: cart.reduce((s, x) => s + x.product.price * x.qty, 0) };
}

type ProductRow = { id: number; name: string; team: string; category: string; price: number; sizes: string[]; stock: number; image: string; front_image?: string; back_image?: string; active: boolean };
export const toProduct = (r: ProductRow): Product => ({ id: r.id, name: r.name, team: r.team, category: r.category, price: r.price, size: r.sizes, stock: r.stock, image: resolveProductImage(r.image), frontImage: resolveProductImage(r.front_image || r.image), backImage: resolveProductImage(r.back_image || r.image), active: r.active });

const fallbackProducts: Product[] = [
  { id: 101, name: "Arsenal Home Jersey", team: "Arsenal", category: "Jerseys", price: 180000, size: ["S", "M", "L", "XL"], stock: 20, image: arsenalImage, active: true },
  { id: 102, name: "Manchester United Home Jersey", team: "Manchester United", category: "Jerseys", price: 180000, size: ["S", "M", "L", "XL"], stock: 20, image: manutdImage, active: true },
  { id: 103, name: "Nigeria Home Jersey", team: "Nigeria", category: "Jerseys", price: 180000, size: ["S", "M", "L", "XL"], stock: 20, image: nigeriaImage, active: true },
  { id: 104, name: "Real Madrid Home Jersey", team: "Real Madrid", category: "Jerseys", price: 180000, size: ["S", "M", "L", "XL"], stock: 20, image: realMadridImage, active: true },
  { id: 105, name: "Uganda Cranes Jersey", team: "Uganda Cranes", category: "Jerseys", price: 180000, size: ["S", "M", "L", "XL"], stock: 20, image: ugandaImage, active: true },
];

export const ORDER_SELECT = "*, order_items(*)";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const toOrder = (r: any): Order => ({
  id: r.id, date: new Date(r.created_at).toLocaleDateString(), total: r.total, subtotal: r.subtotal, deliveryFee: r.delivery_fee,
  status: r.status, deliveryStatus: r.delivery_status, customerName: r.customer_name, phone: r.phone, address: r.address, zone: r.zone,
  riderId: r.rider_id, userId: r.user_id,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  items: (r.order_items ?? []).map((i: any) => ({ productId: i.product_id, name: i.name, size: i.size, qty: i.qty, price: i.price, image: i.image, customization: i.customization ?? undefined })), 
});

type Ctx = Local & {
  update: (fn: (s: Local) => Partial<Local>) => void;
  products: Product[]; allProducts: Product[]; productsLoading: boolean; reloadProducts: () => Promise<void>;
  zones: Zone[]; orders: Order[]; reloadOrders: () => Promise<void>;
  cartCount: number; total: number;
  addToCart: (p: Product, size?: string, customization?: Design) => void;
  changeQty: (i: number, d: number) => void;
  toggleFav: (id: number) => void;
  markViewed: (id: number) => void;
  checkout: (d: CheckoutDetails) => Promise<string | null>;
};

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [state, setState] = useState<Local>(initial);
  const [loaded, setLoaded] = useState(false);
  const [products, setProducts] = useState<Product[]>(fallbackProducts);
  const [productsLoading, setProductsLoading] = useState(false);
  const [zones, setZones] = useState<Zone[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    try {
      const x = JSON.parse(localStorage.getItem(KEY) || "{}");
      setState((s) => ({
        cart: Array.isArray(x.cart) ? x.cart.filter((c: CartItem) => c?.product?.id) : s.cart,
        favourites: x.favourites ?? [], viewed: x.viewed ?? [], savedDesigns: x.savedDesigns ?? [], studio: x.studio ?? s.studio,
      }));
    } catch { /* ignore */ }
    setLoaded(true);
  }, []);
  useEffect(() => { if (loaded) localStorage.setItem(KEY, JSON.stringify(state)); }, [state, loaded]);

  const reloadProducts = useCallback(async () => {
  const [p, z, firebaseProducts] = await Promise.all([
  supabase.from("products").select("*").order("id"),
  supabase.from("delivery_zones").select("*").order("id"),
  fetchFirebaseProducts().catch(() => []),
  ]);
  {
  const firebaseList: Product[] = firebaseProducts.map((item, index) => ({
    id: Number(item.id) || 10000 + index,
    name: item.name,
    team: item.category ?? "Football",
    category: item.category ?? "Jerseys",
    price: item.price,
    size: ["S", "M", "L", "XL", "XXL"],
    stock: 999,
    image: resolveProductImage(item.image),
    frontImage: resolveProductImage(item.frontImage ?? item.image),
    backImage: resolveProductImage(item.backImage ?? item.image),
    active: true,
  }));
  const list = firebaseList.length ? firebaseList : p.data?.length ? p.data.map(toProduct) : fallbackProducts;
  setProducts(list);
      // Keep cart prices current; the cart keeps the photo it was added with.
      setState((s) => ({ ...s, cart: s.cart.flatMap((c) => { const np = list.find((q) => q.id === c.product.id); return np ? [{ ...c, product: np }] : []; }) }));
    }
    if (z.data) setZones(z.data);
    setProductsLoading(false);
  }, []);
  useEffect(() => { void reloadProducts(); }, [reloadProducts]);

  useEffect(() => {
    if (!loaded || !user) return;
    void fetchFirebaseDesigns(user.id).then((designs) => {
      if (designs.length) update((s) => ({ savedDesigns: designs as Design[] }));
    }).catch(() => undefined);
  }, [loaded, user]);

  useEffect(() => {
    if (loaded && user) void saveFirebaseCart(user.id, state.cart).catch(() => undefined);
  }, [loaded, user, state.cart]);

  useEffect(() => {
    if (!user || !state.savedDesigns.length) return;
    const design = state.savedDesigns[state.savedDesigns.length - 1];
    void saveFirebaseDesign(user.id, { ...design, formatVersion: "customization.v1" }).catch(() => undefined);
  }, [user, state.savedDesigns]);

  const reloadOrders = useCallback(async () => {
    if (!user) { setOrders([]); return; }
    const { data } = await supabase.from("orders").select(ORDER_SELECT).eq("user_id", user.id).order("created_at", { ascending: false });
    const firebaseOrders = await fetchFirebaseOrders(user.id).catch(() => []);
    setOrders(firebaseOrders.length ? firebaseOrders as Order[] : (data ?? []).map(toOrder));
  }, [user]);
  useEffect(() => { void reloadOrders(); }, [reloadOrders]);

  const update = useCallback((fn: (s: Local) => Partial<Local>) => setState((s) => ({ ...s, ...fn(s) })), []);
  const { count, total } = cartTotals(state.cart);

  const addToCart = (p: Product, size = "M", customization?: Design) => {
    update((s) => {
      const i = s.cart.findIndex((x) => x.product.id === p.id && x.size === size);
      const cart = [...s.cart];
      const row = cart[i];
      if (row) cart[i] = { ...row, qty: row.qty + 1, customization: customization ?? row.customization }; else cart.push({ product: p, qty: 1, size, image: p.image, customization });
      return { cart };
    });
    toast("Added to cart");
  };
  const changeQty = (i: number, d: number) => update((s) => {
    const cart = [...s.cart]; const row = cart[i]; if (row) cart[i] = { ...row, qty: row.qty + d };
    return { cart: cart.filter((x) => x.qty > 0) };
  });
  const toggleFav = (id: number) => update((s) => ({ favourites: s.favourites.includes(id) ? s.favourites.filter((x) => x !== id) : [...s.favourites, id] }));
  const markViewed = (id: number) => update((s) => ({ viewed: [id, ...s.viewed.filter((x) => x !== id)].slice(0, 5) }));
  const checkout = async (d: CheckoutDetails) => {
    if (!state.cart.length) { toast("Your cart is empty"); return null; }
    if (!user) { toast("Sign in to place your order"); return null; }
    const items = state.cart.map((c) => ({ product_id: c.product.id, size: c.size, qty: c.qty }));
    const { data, error } = await supabase.rpc("place_order", { _items: items, _name: d.name, _phone: d.phone, _address: d.destination ? `${d.address} (${d.destination.label})` : d.address, _zone: d.zone });
    if (error) { toast.error(error.message); return null; }
    void createFirebaseOrder(user.id, {
      sourceOrderId: data,
      customer: d,
      items: state.cart.map((item) => ({ ...item, customization: item.customization ? { ...item.customization, formatVersion: "customization.v1" } : undefined })),
      subtotal: total,
      status: "Pending payment",
    }).catch(() => undefined);
    update(() => ({ cart: [] }));
    toast.success("Order placed. Payment is not connected yet — the store will contact you.");
    void reloadOrders(); void reloadProducts();
    return data as string;
  };

  return (
    <StoreCtx.Provider value={{ ...state, update, products: products.filter((p) => p.active !== false), allProducts: products, productsLoading, reloadProducts, zones, orders, reloadOrders, cartCount: count, total, addToCart, changeQty, toggleFav, markViewed, checkout }}>
      {children}
    </StoreCtx.Provider>
  );
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error("useStore outside StoreProvider");
  return c;
}
