import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { doc, getDoc } from "firebase/firestore";
import { onAuthStateChanged, signOut as firebaseSignOut, type User as FirebaseUser } from "firebase/auth";
import { getFirebaseAuth, getFirebaseApp } from "@/lib/firebase";
import { getFirestore } from "firebase/firestore";

export type Role = "super_admin" | "admin" | "rider";
export type AppUser = { id: string; email: string | null; displayName: string | null; user_metadata: { full_name?: string | null } };
type AuthCtx = { user: AppUser | null; roles: Role[]; loading: boolean; refreshRoles: () => Promise<void>; signOut: () => Promise<void> };
const Ctx = createContext<AuthCtx | null>(null);

function normalizeUser(user: FirebaseUser | null): AppUser | null {
  if (!user) return null;
  return { id: user.uid, email: user.email, displayName: user.displayName, user_metadata: { full_name: user.displayName } };
}

export async function loadFirebaseRoles(userId: string): Promise<Role[]> {
  const app = getFirebaseApp();
  if (!app) return [];
  const data = await getDoc(doc(getFirestore(app), "users", userId));
  const value = data.data() as { roles?: unknown; role?: unknown } | undefined;
  const roles = Array.isArray(value?.roles) ? value.roles : value?.role ? [value.role] : [];
  return roles.filter((role): role is Role => role === "super_admin" || role === "admin" || role === "rider");
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshRoles = useCallback(async () => {
    if (!user) { setRoles([]); return; }
    setRoles(await loadFirebaseRoles(user.id));
  }, [user]);

  useEffect(() => {
    const auth = getFirebaseAuth();
    if (!auth) { setLoading(false); return; }
    return onAuthStateChanged(auth, (nextUser) => {
      const normalized = normalizeUser(nextUser);
      setUser(normalized);
      void (normalized ? loadFirebaseRoles(normalized.id) : Promise.resolve([])).then(setRoles).finally(() => setLoading(false));
    });
  }, []);

  const value: AuthCtx = { user, roles, loading, refreshRoles, signOut: async () => { const auth = getFirebaseAuth(); if (auth) await firebaseSignOut(auth); } };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const context = useContext(Ctx);
  if (!context) throw new Error("useAuth outside AuthProvider");
  return context;
}

export function homeFor(roles: Role[], portal: "customer" | "admin" | "rider") {
  if (portal === "admin") return roles.includes("admin") || roles.includes("super_admin") ? "/admin" : "/profile";
  if (portal === "rider") return roles.includes("rider") ? "/rider" : "/profile";
  return "/profile";
}
