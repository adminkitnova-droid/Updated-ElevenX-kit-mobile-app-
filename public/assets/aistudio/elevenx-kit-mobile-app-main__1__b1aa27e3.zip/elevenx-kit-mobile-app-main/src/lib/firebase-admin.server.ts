async function getAdminApp() {
  const [{ cert, getApps, initializeApp }] = await Promise.all([import("firebase-admin/app")]);
  if (getApps().length) return getApps()[0];
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n");
  if (!process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || !process.env.FIREBASE_CLIENT_EMAIL || !privateKey) {
    throw new Error("Firebase Admin credentials are not configured");
  }
  return initializeApp({
    credential: cert({
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey,
    }),
  });
}

export async function adminAuth() {
  const [{ getAuth }, app] = await Promise.all([import("firebase-admin/auth"), getAdminApp()]);
  return getAuth(app);
}

export async function adminDb() {
  const [{ getFirestore }, app] = await Promise.all([import("firebase-admin/firestore"), getAdminApp()]);
  return getFirestore(app);
}

export async function adminMessaging() {
  const [{ getMessaging }, app] = await Promise.all([import("firebase-admin/messaging"), getAdminApp()]);
  return getMessaging(app);
}

export async function requireFirebaseUser(request: Request) {
  const token = request.headers.get("authorization")?.replace(/^Bearer\\s+/i, "");
  if (!token) throw new Response("Unauthorized", { status: 401 });
  return (await adminAuth()).verifyIdToken(token);
}

export async function requireAdmin(request: Request) {
  const user = await requireFirebaseUser(request);
  if (user.admin !== true && user.role !== "admin") throw new Response("Forbidden", { status: 403 });
  return user;
}
