import type { Product } from "./store";

export function filterProducts(products: Product[], query: string, category: string, sort: string) {
  const q = query.toLowerCase();
  let list = products.filter(
    (p) => (category === "All" || p.category === category) && `${p.name} ${p.team} ${p.category}`.toLowerCase().includes(q),
  );
  if (sort === "low") list = [...list].sort((a, b) => a.price - b.price);
  if (sort === "high") list = [...list].sort((a, b) => b.price - a.price);
  return list;
}
