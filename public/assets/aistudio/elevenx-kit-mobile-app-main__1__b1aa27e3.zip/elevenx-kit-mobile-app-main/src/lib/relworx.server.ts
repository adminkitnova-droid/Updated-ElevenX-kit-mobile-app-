const RELWORX_URL = "https://payments.relworx.com/api/mobile-money/request-payment";

export type RelworxPaymentInput = {
  reference: string;
  msisdn: string;
  amount: number;
  currency?: "UGX" | "KES" | "TZS";
  description: string;
};

export async function requestRelworxPayment(input: RelworxPaymentInput) {
  const response = await fetch(RELWORX_URL, {
    method: "POST",
    headers: {
      Accept: "application/vnd.relworx.v2",
      Authorization: `Bearer ${process.env.RELWORX_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      account_no: process.env.RELWORX_ACCOUNT_ID,
      reference: input.reference,
      msisdn: input.msisdn,
      currency: input.currency ?? "UGX",
      amount: input.amount,
      description: input.description,
    }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message ?? "Relworx payment request failed");
  return payload;
}
