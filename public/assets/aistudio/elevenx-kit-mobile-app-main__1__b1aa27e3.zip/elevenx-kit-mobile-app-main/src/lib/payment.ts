export async function startMobileMoneyPayment(input: { msisdn: string; amount: number; reference?: string }) {
  const response = await fetch("/api/payment/request", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error ?? "Unable to start payment");
  return payload;
}
