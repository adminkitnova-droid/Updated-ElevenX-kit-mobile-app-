import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { ProductImage } from "@/components/product-image";
import { Page } from "@/components/shell";
import { useAuth } from "@/lib/auth";
import { PortalGate } from "@/components/portal-gate";
import { AdminTeam } from "@/components/admin-team";
import { supabase } from "@/integrations/supabase/client";
import { fetchFirebaseHeroSettings, saveFirebaseHeroSettings, saveFirebaseProduct, uploadFirebaseHeroAsset, uploadFirebaseProductImage, type FirebaseHeroSettings } from "@/lib/firebase";
import { BUCKET } from "@/lib/images";
import { money, ORDER_SELECT, toOrder, useStore, type Order, type Product, type Zone } from "@/lib/store";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard | ELEVENX" },
      { name: "description", content: "Manage ELEVENX products, orders, riders and delivery zones." },
      { property: "og:title", content: "Admin Dashboard | ELEVENX" },
      { property: "og:description", content: "Manage ELEVENX products, orders, riders and delivery zones." },
    ],
  }),
  component: () => <PortalGate role="admin"><Admin /></PortalGate>,
});

const statuses = ["Pending payment", "Confirmed", "Preparing", "Ready for dispatch", "Out for delivery", "Delivered", "Cancelled"];
const sections = [["overview", "Overview"], ["products", "Products & prices"], ["orders", "Orders"], ["riders", "Riders"], ["zones", "Delivery zones"], ["customers", "Customers"], ["applications", "Rider applications"], ["admins", "Admins"]] as const;
type RiderInfo = { id: string; name: string; phone: string };

function HeroEditor() {
  const [value, setValue] = useState<FirebaseHeroSettings>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { void fetchFirebaseHeroSettings().then(setValue).catch(() => undefined); }, []);
  const save = async () => { setBusy(true); await saveFirebaseHeroSettings(value); setBusy(false); toast.success("Hero content published"); };
  const upload = async (file?: File) => { if (!file) return; setBusy(true); const url = await uploadFirebaseHeroAsset(file); if (url) setValue((current) => ({ ...current, videoUrl: url })); setBusy(false); };
  return <section className="panel space-y-3"><div><h3 className="font-bold">Hero content</h3><p className="muted">Upload the homepage video and edit the information customers see.</p></div><input type="file" accept="video/*" className="field" onChange={(event) => void upload(event.target.files?.[0])} /><input className="field" placeholder="Hero title" value={value.title ?? ""} onChange={(event) => setValue({ ...value, title: event.target.value })} /><input className="field" placeholder="Hero subtitle" value={value.subtitle ?? ""} onChange={(event) => setValue({ ...value, subtitle: event.target.value })} /><div className="grid grid-cols-2 gap-2"><input className="field" placeholder="Button label" value={value.ctaLabel ?? ""} onChange={(event) => setValue({ ...value, ctaLabel: event.target.value })} /><input className="field" placeholder="Button URL" value={value.ctaUrl ?? ""} onChange={(event) => setValue({ ...value, ctaUrl: event.target.value })} /></div>{value.videoUrl && <video className="h-32 w-full rounded-xl object-cover" src={value.videoUrl} controls muted /> }<button className="btn-gold" disabled={busy} onClick={() => void save()}>{busy ? "SAVING..." : "PUBLISH HERO"}</button></section>;
}

function Admin() {
  const s = useStore();
  const [section, setSection] = useState<string>("overview");
  const [orders, setOrders] = useState<Order[]>([]);
  const [riders, setRiders] = useState<RiderInfo[]>([]);

  const loadOrders = useCallback(async () => {
    const { data, error } = await supabase.from("orders").select(ORDER_SELECT).order("created_at", { ascending: false });
    if (error) toast.error(error.message); else setOrders((data ?? []).map(toOrder));
  }, []);
  const loadRiders = useCallback(async () => {
    const { data: r } = await supabase.from("user_roles").select("user_id").eq("role", "rider");
    const ids = (r ?? []).map((x) => x.user_id);
    if (!ids.length) { setRiders([]); return; }
    const { data: p } = await supabase.from("profiles").select("id, full_name, email, phone").in("id", ids);
    setRiders(ids.map((id) => { const x = p?.find((q) => q.id === id); return { id, name: x?.full_name || x?.email || "Rider", phone: x?.phone ?? "" }; }));
  }, []);
  useEffect(() => { void loadOrders(); void loadRiders(); }, [loadOrders, loadRiders]);

  return (
    <Page>
      <Link to="/profile" className="btn-outline inline-block">← BACK TO PROFILE</Link>
      <div className="section-row">
        <div><div className="section-title">Admin Dashboard</div><p className="muted">Store operations</p></div>
        <span className="pill active">{useAuthRoleLabel()}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2.5 md:grid-cols-4">
        {[["Products", s.allProducts.length], ["Orders", orders.length], ["Riders", riders.length], ["Sales", money(orders.filter((o) => o.status !== "Cancelled").reduce((a, o) => a + o.total, 0))]].map(([k, v]) => (
          <div key={k} className="panel !m-0"><small className="muted">{k}</small><strong className="block font-display text-2xl text-primary">{v}</strong></div>
        ))}
      </div>
      <div className="chips">
        {sections.map(([k, l]) => <button key={k} className={`pill ${section === k ? "active" : ""}`} onClick={() => setSection(k)}>{l}</button>)}
      </div>

      {section === "overview" && (<>
        <HeroEditor />
        <div className="panel">
          <h3 className="font-bold">Store overview</h3>
          <p className="muted">Manage catalogue, order progress, delivery staff and delivery zones.</p>
          <p className="my-2">Customer delivery coverage: {s.zones.filter((z) => z.active).map((z) => z.name).join(", ") || "none"}.</p>
          <p className="muted">All changes are saved to the store database. Online payment is not connected yet.</p>
        </div>
      </>)}
      {section === "products" && (
        <>
          <NewProduct onDone={s.reloadProducts} />
          {s.allProducts.map((p) => <ProductEditor key={p.id} p={p} onDone={s.reloadProducts} />)}
        </>
      )}
      {section === "orders" && (
        <>
          {orders.map((o) => <OrderEditor key={o.id} o={o} riders={riders} onDone={loadOrders} />)}
          {!orders.length && <p className="muted">No orders yet. Orders placed at checkout appear here.</p>}
        </>
      )}
      {section === "riders" && (
        <>
          <p className="muted">Approve new riders under “Rider applications”.</p>
          {riders.map((r) => (
            <div key={r.id} className="panel">
              <b>{r.name}</b><p className="muted">{r.phone || "No phone"} · {orders.filter((o) => o.riderId === r.id).length} assigned · {orders.filter((o) => o.riderId === r.id && o.deliveryStatus === "Delivered").length} delivered</p>
            </div>
          ))}
          {!riders.length && <div className="panel">No approved riders yet.</div>}
        </>
      )}
      {(section === "customers" || section === "applications" || section === "admins") && <AdminTeam view={section} />}
      {section === "zones" && s.zones.map((z) => <ZoneEditor key={z.id} z={z} onDone={s.reloadProducts} />)}
    </Page>
  );
}

async function uploadPhoto(file: File): Promise<string | null> {
  if (!file.type.startsWith("image/")) { toast.error("Choose an image file"); return null; }
  if (file.size > 5 * 1024 * 1024) { toast.error("Photo must be under 5 MB"); return null; }
  try {
    const url = await uploadFirebaseProductImage(file);
    if (url) return url;
  } catch (error) {
    toast.error(error instanceof Error ? error.message : "Firebase upload failed");
  }
  const path = `products/${crypto.randomUUID()}.${file.name.split(".").pop() || "jpg"}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
  if (error) { toast.error(error.message); return null; }
  return path;
}

function ProductFields({ v, set }: { v: Product; set: (x: Partial<Product>) => void }) {
  const [busy, setBusy] = useState(false);
  return (
    <>
      <div className="flex gap-3">
        <div className="flex shrink-0 gap-1"><ProductImage src={v.frontImage || v.image} alt={`${v.name} front view`} className="!w-[56px] rounded-md" /><ProductImage src={v.backImage || v.image} alt={`${v.name} back view`} className="!w-[56px] rounded-md" /></div>
        <div className="flex-1">
          <label className="field-label">Front view image <span className="text-primary">required</span></label>
          <input type="file" accept="image/*" disabled={busy} className="text-xs" onChange={async (e) => {
            const f = e.target.files?.[0]; if (!f) return;
            setBusy(true); const path = await uploadPhoto(f); setBusy(false);
            if (path) { set({ frontImage: path, image: path }); toast("Front image uploaded — save to apply"); }
          }} />
          <label className="field-label mt-2">Back view image <span className="text-primary">required</span></label>
          <input type="file" accept="image/*" disabled={busy} className="text-xs" onChange={async (e) => {
            const f = e.target.files?.[0]; if (!f) return;
            setBusy(true); const path = await uploadPhoto(f); setBusy(false);
            if (path) { set({ backImage: path }); toast("Back image uploaded — save to apply"); }
          }} />
          {busy && <small className="muted block">Uploading…</small>}
        </div>
      </div>
      <label className="field-label mt-2">Name</label>
      <input className="field" value={v.name} onChange={(e) => set({ name: e.target.value })} />
      <label className="field-label">Team</label>
      <input className="field" value={v.team} onChange={(e) => set({ team: e.target.value })} />
      <label className="field-label">Category</label>
      <select className="field" value={v.category} onChange={(e) => set({ category: e.target.value })}><option>Club</option><option>National</option><option>Retro</option><option>Training</option></select>
      <label className="field-label">Sizes (comma separated)</label>
      <input className="field" value={v.size.join(",")} onChange={(e) => set({ size: e.target.value.split(",").map((x) => x.trim().toUpperCase()).filter(Boolean) })} />
      <label className="field-label">Price (UGX)</label>
      <input className="field" type="number" min={0} value={v.price} onChange={(e) => set({ price: Number(e.target.value) })} />
      <label className="field-label">Stock quantity</label>
      <input className="field" type="number" min={0} value={v.stock} onChange={(e) => set({ stock: Number(e.target.value) })} />
      <label className="mb-2 flex items-center gap-2"><input type="checkbox" checked={v.active !== false} onChange={(e) => set({ active: e.target.checked })} /> Show in shop</label>
    </>
  );
}
const row = (v: Product) => ({ name: v.name.trim(), team: v.team.trim(), category: v.category, price: Math.max(0, Math.round(v.price)), stock: Math.max(0, Math.round(v.stock)), sizes: v.size, image: v.frontImage || v.image, active: v.active !== false });
const firebaseRow = (v: Product) => ({ ...row(v), frontImageUrl: v.frontImage || v.image, backImageUrl: v.backImage || v.image });

function ProductEditor({ p, onDone }: { p: Product; onDone: () => Promise<void> }) {
  const [v, setV] = useState(p);
  useEffect(() => setV(p), [p]);
  const save = async () => {
    if (!v.frontImage || !v.backImage) { toast.error("Both front and back images are required"); return; }
    const product = row(v);
    const { error } = await supabase.from("products").update(product).eq("id", p.id);
    if (error) toast.error(error.message); else { await saveFirebaseProduct({ ...firebaseRow(v), id: p.id }); toast.success("Product saved"); void onDone(); }
  };
  return <div className="panel"><b>#{p.id} {p.name}</b><ProductFields v={v} set={(x) => setV({ ...v, ...x })} /><button className="btn-gold" onClick={save}>SAVE PRODUCT</button></div>;
}

const blank = (): Product => ({ id: 0, name: "", team: "", category: "Club", price: 0, size: ["S", "M", "L", "XL"], stock: 0, image: "", frontImage: "", backImage: "", active: true });
function NewProduct({ onDone }: { onDone: () => Promise<void> }) {
  const [open, setOpen] = useState(false);
  const [v, setV] = useState(blank);
  if (!open) return <button className="btn-gold" onClick={() => setOpen(true)}>+ ADD JERSEY</button>;
  const save = async () => {
    if (!v.name.trim() || !v.frontImage || !v.backImage) { toast.error("Add both front and back jersey images"); return; }
    const product = row(v);
    const { data, error } = await supabase.from("products").insert(product).select("id").single();
    if (error) toast.error(error.message); else { await saveFirebaseProduct({ ...firebaseRow(v), id: data.id }); toast.success("Jersey added"); setV(blank()); setOpen(false); void onDone(); }
  };
  return <div className="panel"><b>New jersey</b><ProductFields v={v} set={(x) => setV({ ...v, ...x })} /><button className="btn-gold" onClick={save}>ADD JERSEY</button> <button className="btn-outline" onClick={() => setOpen(false)}>CANCEL</button></div>;
}

function downloadCustomization(item: Order["items"][number]) {
  const design = item.customization;
  if (!design) return;
  const image = design.side === "Front" ? design.frontImage || design.productImage || item.image : design.backImage || design.productImage || item.image;
  const escapeXml = (value: string) => value.replace(/[&<>\"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '\"': "&quot;", "'": "&apos;" }[char] ?? char));
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="1000" viewBox="0 0 800 1000"><rect width="100%" height="100%" fill="#171714"/><image href="${escapeXml(image)}" x="80" y="40" width="640" height="900" preserveAspectRatio="xMidYMid meet"/><g fill="${escapeXml(design.textColor)}" font-family="${escapeXml(design.font)}" text-anchor="middle"><text x="400" y="390" font-size="${Math.max(28, design.fontSize * 0.65)}" font-weight="800">${escapeXml(design.name || "PLAYER NAME")}</text><text x="400" y="570" font-size="${design.fontSize * 2.2}" font-weight="900">${escapeXml(design.number || "10")}</text><text x="400" y="625" font-size="24" font-weight="700">${escapeXml(design.tag || "")}</text></g></svg>`;
  const link = document.createElement("a");
  link.href = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  link.download = `${item.name.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-${design.side.toLowerCase()}-customization.svg`;
  link.click();
}

function CustomizationPreview({ item }: { item: Order["items"][number] }) {
  const design = item.customization;
  if (!design) return null;
  return <div className="mt-2 flex items-center gap-2 rounded-xl border border-gold-line bg-gold-soft p-2"><div className="relative h-20 w-16 overflow-hidden rounded-lg bg-[#1b1b19]"><img src={design.productImage || item.image} alt={`${item.name} customized jersey`} className="h-full w-full object-contain" /><div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center" style={{ color: design.textColor, fontFamily: design.font, fontSize: `${Math.max(8, design.fontSize * 0.18)}px` }}><strong>{design.name}</strong><b>{design.number}</b></div></div><div><small className="block font-bold">CUSTOMIZATION</small><small className="muted">{design.font} · {design.fontSize}px · {design.side} view</small><button type="button" className="btn-outline mt-1 inline-flex items-center gap-1 px-2 py-1 text-[10px]" onClick={() => downloadCustomization(item)}><Download className="h-3 w-3" /> EXPORT</button></div></div>;
}

function OrderEditor({ o, riders, onDone }: { o: Order; riders: RiderInfo[]; onDone: () => Promise<void> }) {
  const [status, setStatus] = useState(o.status);
  const [rider, setRider] = useState(o.riderId ?? "");
  const save = async () => {
    const changes: { status: string; rider_id: string | null; delivery_status?: string } = { status, rider_id: rider || null };
    if ((rider || null) !== o.riderId) changes.delivery_status = rider ? "Assigned" : "Unassigned";
    const { error } = await supabase.from("orders").update(changes).eq("id", o.id);
    if (error) toast.error(error.message); else { toast.success("Order updated"); void onDone(); }
  };
  return (
    <div className="panel">
      <b>{o.id}</b><p className="muted">{o.date} · {money(o.total)} (incl. {money(o.deliveryFee)} delivery)</p>
      <p className="text-sm">{o.customerName} · {o.phone}<br />{o.zone} — {o.address}</p>
      {o.items.map((it) => (
        <div key={it.productId + it.size} className="mt-2 flex items-center gap-2"><ProductImage src={it.image} alt={it.name} className="!w-[48px] shrink-0 rounded-md" /><small>{it.name} · {it.size} × {it.qty} · {money(it.price)}</small>{it.customization && <CustomizationPreview item={it} />}</div>
      ))}
      <label className="field-label mt-2">Order status</label>
      <select className="field" value={status} onChange={(e) => setStatus(e.target.value)}>{statuses.map((x) => <option key={x}>{x}</option>)}</select>
      <label className="field-label">Rider · delivery: {o.deliveryStatus}</label>
      <select className="field" value={rider} onChange={(e) => setRider(e.target.value)}>
        <option value="">Not assigned</option>
        {riders.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
      </select>
      <button className="btn-outline" onClick={save}>UPDATE ORDER</button>
    </div>
  );
}

function ZoneEditor({ z, onDone }: { z: Zone; onDone: () => Promise<void> }) {
  const [v, setV] = useState(z);
  const save = async () => {
    const { error } = await supabase.from("delivery_zones").update({ fee: Math.max(0, Math.round(v.fee)), eta: v.eta, active: v.active }).eq("id", z.id);
    if (error) toast.error(error.message); else { toast.success("Delivery zone saved"); void onDone(); }
  };
  return (
    <div className="panel">
      <b>{z.name}</b>
      <label className="field-label mt-2">Delivery fee (UGX)</label>
      <input className="field" type="number" min={0} value={v.fee} onChange={(e) => setV({ ...v, fee: Number(e.target.value) })} />
      <label className="field-label">Estimated delivery</label>
      <input className="field" value={v.eta} onChange={(e) => setV({ ...v, eta: e.target.value })} />
      <label className="mb-2 flex items-center gap-2"><input type="checkbox" checked={v.active} onChange={(e) => setV({ ...v, active: e.target.checked })} /> Zone active</label>
      <button className="btn-outline" onClick={save}>SAVE ZONE</button>
    </div>
  );
}

function useAuthRoleLabel() {
  const { roles } = useAuth();
  return roles.includes("super_admin") ? "Super Admin" : "Admin";
}
