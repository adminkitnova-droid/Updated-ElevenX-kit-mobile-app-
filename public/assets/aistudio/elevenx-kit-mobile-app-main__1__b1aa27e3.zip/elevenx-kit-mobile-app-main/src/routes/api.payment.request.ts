import { createFileRoute } from "@tanstack/react-router";
import { requireFirebaseUser } from "@/lib/firebase-admin.server";
import { requestRelworxPayment } from "@/lib/relworx.server";

export const Route = createFileRoute("/api/payment/request")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const user = await requireFirebaseUser(request);
        const body = (await request.json()) as { msisdn?: string; amount?: number; reference?: string };
        if (!body.msisdn || !Number.isFinite(body.amount) || body.amount <= 0) {
          return Response.json({ error: "A valid phone number and amount are required." }, { status: 400 });
        }
        const payment = await requestRelworxPayment({
          msisdn: body.msisdn,
          amount: body.amount,
          reference: body.reference ?? `ELEVENX-${user.uid}-${Date.now()}`,
          description: "ELEVENX jersey order",
        });
        return Response.json(payment);
      },
    },
  },
});
