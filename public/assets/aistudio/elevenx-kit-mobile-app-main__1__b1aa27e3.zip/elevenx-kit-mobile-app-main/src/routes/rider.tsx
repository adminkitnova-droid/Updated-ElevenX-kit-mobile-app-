import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { ProductImage } from "@/components/product-image";
import { Page } from "@/components/shell";
import { PortalGate } from "@/components/portal-gate";
import { RiderApplication } from "@/components/rider-application";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { money, ORDER_SELECT, toOrder, type Order } from "@/lib/store";
import { subscribeToFirebaseRiderOrders } from "@/lib/firebase";

export const Route = createFileRoute("/rider")({
  head: () => ({
    meta: [
      { title: "Rider Portal | ELEVENX" },
      { name: "description", content: "View assigned ELEVENX deliveries and update their status." },
      { property: "og:title", content: "Rider Portal | ELEVENX" },
      { property: "og:description", content: "View assigned ELEVENX deliveries and update their status." },
    ],
  }),
  component: () => <PortalGate role="rider" fallback={<RiderApplication />}><Rider /></PortalGate>,
});

const statuses = ["Assigned", "Accepted", "Picked up", "On the way", "Delivered", "Failed delivery"];

function Rider() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from("orders").select(ORDER_SELECT).eq("rider_id", user.id).order("created_at", { ascending: false });
    setOrders((data ?? []).map(toOrder)); setLoading(false);
  }, [user]);
  useEffect(() => {
    void load();
    if (!user) return;
    return subscribeToFirebaseRiderOrders(user.id, (records) => {
      setOrders(records.map((record) => toOrder(record as Parameters<typeof toOrder>[0])));
      setLoading(false);
    });
  }, [load, user]);

  const setStatus = async (id: string, status: string) => {
    const { error } = await supabase.rpc("rider_update_delivery", { _order_id: id, _status: status });
    if (error) toast.error(error.message); else { toast.success("Delivery updated"); void load(); }
  };

  return (
    <Page>
      <Link to="/profile" className="btn-outline inline-block">← BACK TO PROFILE</Link>
      <div className="section-title">Rider Portal</div>
      <p className="muted">Your assigned deliveries</p>
      <div className="panel flex items-center gap-4">
        <div className="grid h-14 w-14 place-items-center rounded-full bg-primary text-2xl font-black text-primary-foreground">R</div>
        <div><h2 className="text-lg font-bold">{user?.user_metadata?.["full_name"] || user?.email}</h2><p className="muted">{orders.filter((o) => o.deliveryStatus !== "Delivered").length} open · {orders.filter((o) => o.deliveryStatus === "Delivered").length} delivered</p></div>
      </div>
      {orders.map((o) => (
        <div key={o.id} className="panel space-y-1">
          <div className="section-row"><b>{o.id}</b><span className="pill active">{o.deliveryStatus}</span></div>
          {o.items.map((it) => (
            <div key={it.productId + it.size} className="flex items-center gap-2"><ProductImage src={it.image} alt={it.name} className="!w-[48px] shrink-0 rounded-md" /><small>{it.name} · {it.size} × {it.qty}</small></div>
          ))}
          <p><b>Customer:</b> {o.customerName}</p>
          <p><b>Phone:</b> <a className="gold" href={`tel:${o.phone}`}>{o.phone}</a></p>
          <p><b>Delivery area:</b> {o.zone}</p>
          <p><b>Address:</b> {o.address}</p>
          <p><b>Order total:</b> {money(o.total)}</p>
          <label className="field-label pt-2">Update delivery status</label>
          <select className="field" value={o.deliveryStatus} onChange={(e) => void setStatus(o.id, e.target.value)}>
            {statuses.map((x) => <option key={x} disabled={x === "Assigned"}>{x}</option>)}
          </select>
        </div>
      ))}
      {!loading && !orders.length && <div className="panel">No deliveries assigned yet.</div>}
    </Page>
  );
}
