import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AuthForm } from "@/components/auth-form";
import { Page } from "@/components/shell";
import { homeFor, useAuth } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in | ELEVENX" },
      { name: "description", content: "Sign in or create your ELEVENX customer account." },
      { property: "og:title", content: "Sign in | ELEVENX" },
      { property: "og:description", content: "Sign in or create your ELEVENX customer account." },
    ],
  }),
  component: Login,
});

function Login() {
  const { user, roles, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && user) navigate({ to: homeFor(roles, "customer"), replace: true }); }, [user, roles, loading, navigate]);
  return <Page><AuthForm portal="customer" /></Page>;
}
