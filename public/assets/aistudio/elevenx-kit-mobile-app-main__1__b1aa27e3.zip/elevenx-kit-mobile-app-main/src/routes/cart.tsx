import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { ProductImage } from "@/components/product-image";
import { GeoapifyDeliveryMap } from "@/components/geoapify-delivery-map";
import { Page } from "@/components/shell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { money, useStore } from "@/lib/store";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart | ELEVENX" },
      { name: "description", content: "Review the jerseys in your cart and place your order." },
      { property: "og:title", content: "Your Cart | ELEVENX" },
      { property: "og:description", content: "Review the jerseys in your cart and place your order." },
    ],
  }),
  component: Cart,
});

function Cart() {
  const { cart, cartCount, total, changeQty, checkout, zones } = useStore();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [d, setD] = useState<{ name: string; phone: string; address: string; zone: string; destination?: { lat: number; lon: number; label: string }; distanceKm?: number; deliveryFee?: number }>({ name: "", phone: "", address: "", zone: "" });
  const [busy, setBusy] = useState(false);
  const active = zones.filter((z) => z.active);
  const zone = active.find((z) => z.name === d.zone);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("full_name, phone, address").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data) setD((x) => ({ ...x, name: x.name || data.full_name || "", phone: x.phone || data.phone || "", address: x.address || data.address || "" }));
    });
  }, [user]);
  useEffect(() => { if (!d.zone && active[0]) setD((x) => ({ ...x, zone: active[0]!.name })); }, [active, d.zone]);

  const place = async () => {
    setBusy(true);
    const id = await checkout(d);
    setBusy(false);
    if (id) navigate({ to: "/profile" });
  };

  return (
    <Page>
      <div className="section-title">Your Cart <span className="gold">({cartCount})</span></div>
      {cart.map((item, i) => (
        <div key={item.product.id + item.size} className="panel flex items-center gap-3">
          <ProductImage src={item.image} alt={item.product.name} className="!w-[80px] shrink-0 rounded-[10px]" />
          <div className="flex flex-1 flex-col gap-1">
            <b className="text-[13px]">{item.product.name}</b>
            <small className="muted">Size {item.size}</small>
            <strong className="gold">{money(item.product.price * item.qty)}</strong>
            <div className="flex items-center gap-3">
              <button className="h-6 w-7 rounded-md bg-accent text-primary" onClick={() => changeQty(i, -1)}>−</button>{item.qty}
              <button className="h-6 w-7 rounded-md bg-accent text-primary" onClick={() => changeQty(i, 1)}>+</button>
            </div>
          </div>
          <button aria-label="Remove" className="text-primary" onClick={() => changeQty(i, -item.qty)}><Trash2 className="h-5 w-5" /></button>
        </div>
      ))}
      {cart.length ? (
        <div className="panel">
          <div className="section-row"><b>Subtotal</b><b className="gold">{money(total)}</b></div>
          {!user ? (
            <>
              <p className="muted mb-2">Sign in to enter your delivery details and place the order.</p>
              <Link to="/auth" className="btn-gold full inline-block text-center">SIGN IN TO CHECKOUT</Link>
            </>
          ) : (
            <>
              <label className="field-label mt-2">Full name</label>
              <input className="field" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} />
              <label className="field-label">Phone</label>
              <input className="field" inputMode="tel" value={d.phone} onChange={(e) => setD({ ...d, phone: e.target.value })} />
              <label className="field-label">Delivery area</label>
              <select className="field" value={d.zone} onChange={(e) => setD({ ...d, zone: e.target.value })}>
                {active.map((z) => <option key={z.id} value={z.name}>{z.name} · {money(z.fee)} · {z.eta}</option>)}
              </select>
              <label className="field-label">Delivery address</label>
              <input className="field" value={d.address} onChange={(e) => setD({ ...d, address: e.target.value })} />
              <label className="field-label">Select destination</label>
              <GeoapifyDeliveryMap value={d.destination ?? null} onChange={(destination, route) => setD((current) => ({ ...current, destination, distanceKm: route.distanceKm, deliveryFee: Math.max(zone?.fee ?? 0, Math.round(route.distanceKm * 1000)) }))} />
              <div className="section-row"><span>Delivery fee {d.distanceKm ? `(${d.distanceKm.toFixed(1)} km)` : ""}</span><span>{money(d.deliveryFee ?? zone?.fee ?? 0)}</span></div>
              <div className="section-row"><b>Total</b><b className="gold">{money(total + (d.deliveryFee ?? zone?.fee ?? 0))}</b></div>
              <p className="muted">Online payment is not connected yet. The store will contact you to arrange payment.</p>
              <button className="btn-gold full" disabled={busy || !d.phone.trim() || !d.address.trim() || !zone || !d.destination} onClick={place}>{busy ? "PLACING ORDER…" : "PLACE ORDER"}</button>
            </>
          )}
        </div>
      ) : (
        <div className="panel">
          <h3 className="font-bold">Your cart is empty</h3>
          <p className="muted mb-3">Find a jersey to get started.</p>
          <Link to="/search" className="btn-gold inline-block">SHOP JERSEYS</Link>
        </div>
      )}
    </Page>
  );
}
