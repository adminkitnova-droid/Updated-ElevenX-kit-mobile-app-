import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";
import { ProductImage } from "@/components/product-image";
import { Page } from "@/components/shell";
import { money, useStore } from "@/lib/store";

export const Route = createFileRoute("/product/$id")({
  head: () => ({
    meta: [
      { title: "Jersey details | ELEVENX" },
      { name: "description", content: "Choose your size and add this football jersey to your cart." },
      { property: "og:title", content: "Jersey details | ELEVENX" },
      { property: "og:description", content: "Choose your size and add this football jersey to your cart." },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const router = useRouter();
  const { products, favourites, addToCart, toggleFav, markViewed, update } = useStore();
  const p = products.find((x) => String(x.id) === id);
  const [size, setSize] = useState("M");
  useEffect(() => { if (p) markViewed(p.id); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!p) return <Page><p className="muted">Jersey not found.</p><Link to="/search" className="btn-gold inline-block">SHOP JERSEYS</Link></Page>;
  return (
    <Page>
      <button className="btn-outline mb-3 flex items-center gap-1" onClick={() => router.history.back()}><ArrowLeft className="h-4 w-4" /> Back</button>
      <section className="grid items-start gap-5 md:grid-cols-2">
        <ProductImage src={p.image} alt={p.name} className="rounded-2xl md:max-w-[420px]" />
        <div>
          <span className="gold">{p.team}</span>
          <h1 className="my-2 font-display text-3xl font-extrabold">{p.name}</h1>
          <h2 className="gold mb-2 text-xl font-bold">{money(p.price)}</h2>
          <p className="muted">Available sizes: {p.size.join(", ")} · {p.stock} in stock</p>
          <label className="field-label mt-3">Choose size</label>
          <select className="field" value={size} onChange={(e) => setSize(e.target.value)}>
            {p.size.map((s) => <option key={s}>{s}</option>)}
          </select>
          <button className="btn-gold full" onClick={() => addToCart(p, size)}>ADD TO CART</button>
          <button className="btn-outline full" onClick={() => toggleFav(p.id)}>{favourites.includes(p.id) ? "♥ Saved" : "♡ Add to favourites"}</button>
          <Link to="/studio" className="btn-outline full text-center" onClick={() => update((s) => ({ studio: { ...s.studio, productId: p.id, jersey: p.team, productImage: p.frontImage ?? p.image, frontImage: p.frontImage ?? p.image, backImage: p.backImage ?? p.image, side: "Front" } }))}>CUSTOMIZE THIS JERSEY</Link>
        </div>
      </section>
    </Page>
  );
}
