import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, ImagePlus, Move, PanelRightClose, PanelRightOpen, RotateCcw, Save, ShoppingBag, Upload } from "lucide-react";
import { Page } from "@/components/shell";
import { defaultDesign, useStore, type Design } from "@/lib/store";

export const Route = createFileRoute("/studio")({
  head: () => ({ meta: [{ title: "Personalization Studio | ELEVENX" }, { name: "description", content: "Personalize an official ELEVENX football jersey with a name, number, tag number, and uploaded artwork." }] }),
  component: Studio,
});

function Studio() {
  const { studio, update, products, savedDesigns, addToCart } = useStore();
  const [active, setActive] = useState<"name" | "number" | "tag" | "artwork">("name");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const artworkDrag = useRef<{ x: number; y: number; startX: number; startY: number } | null>(null);
  const product = products.find((p) => p.id === studio.productId) ?? products[0];
  const imageForSide = product ? (studio.side === "Front" ? product.frontImage ?? product.image : product.backImage ?? product.image) : "";
  const set = (patch: Partial<Design>) => update((s) => ({ studio: { ...s.studio, ...patch, productId: product?.id, productImage: imageForSide, frontImage: product?.frontImage ?? product?.image, backImage: product?.backImage ?? product?.image } }));

  useEffect(() => {
    if (product && (studio.productId !== product.id || studio.productImage !== imageForSide)) set({ productId: product.id, productImage: imageForSide, jersey: product.team, frontImage: product.frontImage ?? product.image, backImage: product.backImage ?? product.image });
  }, [product?.id, product?.frontImage, product?.backImage, imageForSide, studio.productId, studio.productImage]);

  const startArtworkDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const target = event.currentTarget;
    target.setPointerCapture(event.pointerId);
    artworkDrag.current = { x: studio.artworkX, y: studio.artworkY, startX: event.clientX, startY: event.clientY };
  };

  const moveArtwork = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = artworkDrag.current;
    const canvas = canvasRef.current;
    if (!drag || !canvas) return;
    const rect = canvas.getBoundingClientRect();
    set({ artworkX: Math.max(8, Math.min(92, drag.x + ((event.clientX - drag.startX) / rect.width) * 100)), artworkY: Math.max(8, Math.min(92, drag.y + ((event.clientY - drag.startY) / rect.height) * 100)) });
  };

  const endArtworkDrag = () => { artworkDrag.current = null; };

  const upload = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image file"); return; }
    const reader = new FileReader();
    reader.onload = () => set({ artworkImage: String(reader.result), artwork: file.name });
    reader.readAsDataURL(file);
  };

  const save = () => { update((s) => ({ savedDesigns: [...s.savedDesigns, { ...s.studio, id: Date.now(), productId: product?.id, productImage: imageForSide, frontImage: product?.frontImage ?? product?.image, backImage: product?.backImage ?? product?.image, formatVersion: "customization.v1" } as Design] })); toast.success("Design saved"); };
  const load = (design: Design) => { update((s) => ({ studio: { ...s.studio, ...design, productId: design.productId, productImage: design.productImage } })); toast.success("Design reopened"); };
  const add = () => { if (product) { addToCart(product, "M", studio); toast.success("Personalized jersey added"); } };

  return <Page>
    <div className="mb-4 flex items-start justify-between gap-3">
      <div className="min-w-0"><p className="mb-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary">ELEVENX / STUDIO</p><h1 className="font-display text-[28px] font-extrabold leading-none tracking-tight sm:text-3xl">Personalize your jersey</h1><p className="mt-2 text-xs text-muted-foreground sm:text-sm">Add only the details that go on your jersey.</p></div>
      <div className="flex shrink-0 items-center gap-2"><button type="button" aria-expanded={sidebarOpen} aria-controls="studio-tools" onClick={() => setSidebarOpen(true)} className="inline-flex min-h-9 items-center gap-1.5 rounded-xl border border-border bg-card px-3 text-[10px] font-bold uppercase tracking-wider text-foreground transition hover:border-primary"><PanelRightOpen className="h-4 w-4" /> Open toolbar</button><span className="rounded-full border border-gold-line bg-gold-soft px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-primary">4 tools</span></div>
    </div>
    <section className="rounded-[22px] border border-gold-line bg-[#141411] p-3 shadow-2xl">
      <div className="mb-3 flex items-center justify-between"><div><p className="text-[10px] uppercase tracking-[0.18em] text-primary">Selected product</p><p className="font-display text-xl font-bold">{product?.name ?? "Loading jersey"}</p></div><span className="text-xs text-muted-foreground">{studio.side} view</span></div>
      <div ref={canvasRef} className="studio-canvas relative mx-auto flex min-h-[300px] touch-none items-center justify-center overflow-hidden rounded-2xl bg-[radial-gradient(circle_at_50%_40%,#34342e,#1b1b19_65%)] p-3 sm:min-h-[350px] sm:p-5">
        {product ? <img src={studio.productImage || product.image} alt={`${product.name} personalization canvas`} className="max-h-[340px] w-full object-contain" /> : <p className="text-muted-foreground">No jerseys available</p>}
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center pt-8 text-center" style={{ color: studio.textColor }}>
          {studio.side === "Back" && <><span className="max-w-[76%] truncate font-black tracking-[0.22em] drop-shadow-lg" style={{ fontFamily: studio.font, fontSize: `${Math.max(18, studio.fontSize * 0.28)}px` }}>{studio.name || "PLAYER NAME"}</span><strong className="leading-[0.82] drop-shadow-lg" style={{ fontFamily: studio.font, fontSize: `${studio.fontSize}px` }}>{studio.number || "10"}</strong><span className="mt-2 text-xs font-bold tracking-[0.3em] drop-shadow-lg">{studio.tag}</span></>}
        </div>
        {studio.artworkImage && <div className="absolute cursor-grab touch-none active:cursor-grabbing" onPointerDown={startArtworkDrag} onPointerMove={moveArtwork} onPointerUp={endArtworkDrag} onPointerCancel={endArtworkDrag} style={{ left: `${studio.artworkX}%`, top: `${studio.artworkY}%`, transform: `translate(-50%, -50%) scale(${studio.artworkScale})` }}><img src={studio.artworkImage} alt="Uploaded artwork" draggable={false} className="h-16 w-16 select-none object-contain drop-shadow-lg" /></div>}
      </div>
      <div className="mt-3 flex items-center justify-center gap-2"><button className={`pill ${studio.side === "Front" ? "active" : ""}`} onClick={() => set({ side: "Front", productImage: product?.frontImage ?? product?.image })}>FRONT</button><button className={`pill ${studio.side === "Back" ? "active" : ""}`} onClick={() => set({ side: "Back", productImage: product?.backImage ?? product?.image })}>BACK</button></div>
    </section>
    {sidebarOpen && <><button type="button" aria-label="Close tools sidebar" onClick={() => setSidebarOpen(false)} className="fixed inset-0 z-30 bg-black/40" /><aside id="studio-tools" aria-label="Studio tools" className="fixed inset-y-0 left-0 z-40 w-[min(92vw,380px)] overflow-y-auto border-l border-gold-line bg-background p-4 shadow-2xl"><div className="mb-4 flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Studio tools</p><p className="text-sm text-muted-foreground">Name, number, tag and image</p></div><button type="button" aria-label="Close tools sidebar" onClick={() => setSidebarOpen(false)} className="rounded-xl border border-border px-3 py-2 text-[10px] font-bold uppercase tracking-wider hover:border-primary"><PanelRightClose className="h-4 w-4" /></button></div>
    <div className="mt-4 grid grid-cols-4 gap-2">{([ ["name", "Name"], ["number", "Number"], ["tag", "Tag"], ["artwork", "Image"] ] as const).map(([key, label]) => <button key={key} onClick={() => setActive(key)} className={`rounded-xl border px-2 py-3 text-center text-[11px] font-bold ${active === key ? "border-primary bg-gold-soft text-primary" : "border-border bg-card text-muted-foreground"}`}>{key === "artwork" ? <ImagePlus className="mx-auto mb-1 h-4 w-4" /> : key === "name" ? "Aa" : key === "number" ? "12" : "#"}<span className="block">{label}</span></button>)}</div>
    <section className="panel mt-3">
      {active === "name" && <><label className="field-label">Player name</label><input className="field" maxLength={15} value={studio.name} onChange={(e) => set({ name: e.target.value.toUpperCase() })} placeholder="YOUR NAME" /><p className="muted">Printed on the back of the selected jersey.</p><div className="mt-3 grid grid-cols-2 gap-2"><label className="field-label">Font family<select className="field mt-1" value={studio.font} onChange={(e) => set({ font: e.target.value })}><option>Arial</option><option>Georgia</option><option>Impact</option><option>Verdana</option><option>Courier New</option></select></label><label className="field-label">Font color<input className="field mt-1 h-10 p-1" type="color" value={studio.textColor} onChange={(e) => set({ textColor: e.target.value })} /></label></div><label className="field-label mt-3">Font size <span className="float-right text-muted-foreground">{studio.fontSize}px</span><input className="mt-2 w-full" type="range" min="28" max="104" step="1" value={studio.fontSize} onChange={(e) => set({ fontSize: Number(e.target.value) })} /></label></>}
      {active === "number" && <><label className="field-label">Player number</label><input className="field" inputMode="numeric" maxLength={2} value={studio.number} onChange={(e) => set({ number: e.target.value.replace(/[^0-9]/g, "").slice(0, 2) })} placeholder="10" /><p className="muted">Use a number from 1 to 99.</p></>}
      {active === "tag" && <><label className="field-label">Small tag number</label><input className="field" maxLength={6} value={studio.tag} onChange={(e) => set({ tag: e.target.value.toUpperCase() })} placeholder="OPTIONAL" /><p className="muted">Appears beneath the main player number.</p></>}
      {active === "artwork" && <><input ref={fileInput} type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} /><button className="btn-outline flex w-full items-center justify-center gap-2" onClick={() => fileInput.current?.click()}><Upload className="h-4 w-4" /> {studio.artworkImage ? "Replace uploaded image" : "Upload logo or image"}</button>{studio.artworkImage && <div className="mt-3 grid grid-cols-2 gap-3"><label className="field-label">Size<input type="range" min="0.5" max="2" step="0.1" value={studio.artworkScale} onChange={(e) => set({ artworkScale: Number(e.target.value) })} className="mt-2 w-full" /></label><div className="flex items-end gap-1"><button className="btn-outline" onClick={() => set({ artworkX: Math.max(8, studio.artworkX - 5) })}><ArrowLeft className="h-4 w-4" /></button><button className="btn-outline" onClick={() => set({ artworkX: Math.min(92, studio.artworkX + 5) })}><Move className="h-4 w-4" /></button></div></div>}</>}
      <div className="mt-4 grid grid-cols-2 gap-2"><button className="btn-outline flex items-center justify-center gap-2" onClick={() => { update(() => ({ studio: defaultDesign() })); toast("Studio reset"); }}><RotateCcw className="h-4 w-4" /> Reset</button><button className="btn-gold flex items-center justify-center gap-2" onClick={save}><Save className="h-4 w-4" /> Save design</button></div>
    </section>
    </aside></>}
    {savedDesigns.length > 0 && <section className="panel mt-3"><div className="mb-3 flex items-center justify-between"><div><p className="field-label mb-0">Saved designs</p><p className="muted">Reopen a saved personalization.</p></div><span className="text-[10px] font-bold text-muted-foreground">{savedDesigns.length}</span></div><div className="grid gap-2 sm:grid-cols-2">{savedDesigns.slice(-4).reverse().map((design) => <button key={design.id} onClick={() => load(design)} className="flex items-center gap-3 rounded-xl border border-border bg-card p-2 text-left transition hover:border-primary"><img src={design.productImage} alt="Saved jersey" className="h-12 w-10 rounded-lg object-contain" /><span className="min-w-0"><strong className="block truncate text-xs">{design.name || "Unnamed player"}</strong><span className="block text-[11px] text-muted-foreground">#{design.number || "—"} · {design.tag || "No tag"}</span></span></button>)}</div></section>}
    <div className="sticky bottom-3 z-20 mt-4 rounded-2xl border border-gold-line bg-background/95 p-2 shadow-xl backdrop-blur sm:static sm:border-0 sm:bg-transparent sm:p-0 sm:shadow-none sm:backdrop-blur-none"><button className="btn-gold full flex min-h-12 items-center justify-center gap-2 text-sm" onClick={add}><ShoppingBag className="h-4 w-4" /> Add personalized jersey to cart</button></div>
    <p className="mt-3 text-center text-[11px] text-muted-foreground">Your original product image stays unchanged. Personalization is saved as separate order details.</p>
  </Page>;
}
