import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Page, ProductCard } from "@/components/shell";
import { fetchFirebaseHeroSettings, type FirebaseHeroSettings } from "@/lib/firebase";
import { useStore } from "@/lib/store";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ELEVENX | Premium Football Jerseys" },
      { name: "description", content: "Shop club and national football jerseys or design your own custom kit." },
      { property: "og:title", content: "ELEVENX | Premium Football Jerseys" },
      { property: "og:description", content: "Shop club and national football jerseys or design your own custom kit." },
    ],
  }),
  component: Home,
});

function Home() {
  const { products, viewed } = useStore();
  const navigate = useNavigate();
  const [hero, setHero] = useState<FirebaseHeroSettings>({});
  useEffect(() => { void fetchFirebaseHeroSettings().then(setHero).catch(() => undefined); }, []);
  return (
    <Page>
      <div className="hero relative overflow-hidden">
        {hero.videoUrl && <video className="absolute inset-0 h-full w-full object-cover opacity-35" src={hero.videoUrl} autoPlay muted loop playsInline />}
        <div className="relative z-10"><span className="pill">THE NEW SEASON COLLECTION</span><h1 className="mb-2 mt-4 font-display text-[38px] leading-none tracking-wide md:text-[54px]">{hero.title || <>WEAR YOUR<br /><em className="not-italic text-primary">PASSION.</em></>}</h1><p className="mb-4 text-[13px] text-muted-foreground">{hero.subtitle || "Premium football kits. Your team. Your identity."}</p><Link to={(hero.ctaUrl || "/search") as "/search"} className="btn-gold inline-block">{hero.ctaLabel || "SHOP JERSEYS →"}</Link></div><div className="relative z-10 text-[100px] opacity-85">⚽</div>
      </div>
      <div className="section-title">Shop by collection</div>
      <div className="chips">
        {["All", "Club", "National"].map((c) => (
          <button key={c} className="pill" onClick={() => navigate({ to: "/search", search: { category: c } })}>{c === "All" ? "All Jerseys" : c + " Teams"}</button>
        ))}
        <Link to="/studio" className="pill">Custom Kits</Link>
      </div>
      <div className="section-row">
        <div className="section-title">Featured jerseys</div>
        <Link to="/search" className="text-primary">View all</Link>
      </div>
      <div className="product-grid">{products.slice(0, 4).map((p) => <ProductCard key={p.id} p={p} />)}</div>
      <div className="section-title">Recently viewed</div>
      <div className="chips">
        {!viewed.length && <span className="muted">Your recently viewed jerseys will appear here.</span>}
        {viewed.map((id) => {
          const p = products.find((x) => x.id === id);
          return p ? <Link key={id} className="pill" to="/product/$id" params={{ id: String(id) }}>{p.name}</Link> : null;
        })}
      </div>
    </Page>
  );
}
