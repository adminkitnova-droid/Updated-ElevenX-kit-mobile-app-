import { createFileRoute } from "@tanstack/react-router";
import { adminDb, adminMessaging, requireAdmin } from "@/lib/firebase-admin.server";

export const Route = createFileRoute("/api/notifications/publish")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const admin = await requireAdmin(request);
        const body = (await request.json()) as { title?: string; body?: string; audience?: "customers" | "riders" | "admins" | "all" };
        if (!body.title?.trim() || !body.body?.trim()) return Response.json({ error: "Title and message are required." }, { status: 400 });
        const notification = { title: body.title.trim(), body: body.body.trim(), audience: body.audience ?? "all", publishedBy: admin.uid, publishedAt: new Date().toISOString() };
        const db = await adminDb();
        const messaging = await adminMessaging();
        const ref = await db.collection("notifications").add(notification);
        const users = await db.collection("users").get();
        const tokens = users.docs.flatMap((doc) => {
          const data = doc.data();
          const role = data.role ?? "customer";
          const allowed = notification.audience === "all" || notification.audience === `${role}s` || (notification.audience === "admins" && role === "admin");
          return allowed && Array.isArray(data.fcmTokens) ? data.fcmTokens.filter((token): token is string => typeof token === "string") : [];
        });
        if (tokens.length) await messaging.sendEachForMulticast({ tokens, notification: { title: notification.title, body: notification.body }, data: { notificationId: ref.id } });
        return Response.json({ id: ref.id, delivered: tokens.length });
      },
    },
  },
});
