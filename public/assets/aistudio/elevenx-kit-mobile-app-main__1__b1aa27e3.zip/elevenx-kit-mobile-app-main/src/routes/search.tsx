import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Page, ProductCard } from "@/components/shell";
import { useStore } from "@/lib/store";
import { filterProducts } from "@/lib/catalog";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): { category?: string } => (typeof s["category"] === "string" ? { category: s["category"] } : {}),
  head: () => ({
    meta: [
      { title: "Find your kit | ELEVENX" },
      { name: "description", content: "Search club and national team jerseys by name, team or country." },
      { property: "og:title", content: "Find your kit | ELEVENX" },
      { property: "og:description", content: "Search club and national team jerseys by name, team or country." },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { products } = useStore();
  const { category: initial } = Route.useSearch();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(initial ?? "All");
  const [sort, setSort] = useState("popular");
  const list = filterProducts(products, query, category, sort);
  return (
    <Page>
      <div className="section-title">Find your kit</div>
      <input className="field text-[15px]" placeholder="Search club, country or jersey..." value={query} onChange={(e) => setQuery(e.target.value)} />
      <div className="chips">
        {["All", "Club", "National"].map((c) => (
          <button key={c} className={`pill ${category === c ? "active" : ""}`} onClick={() => setCategory(c)}>{c}</button>
        ))}
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>{list.length} products</span>
        <select className="field w-auto min-w-[150px]" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="popular">Popular</option>
          <option value="low">Price: low to high</option>
          <option value="high">Price: high to low</option>
        </select>
      </div>
      <div className="product-grid">{list.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      {!list.length && <p className="muted">No jerseys found. Try another search.</p>}
    </Page>
  );
}
