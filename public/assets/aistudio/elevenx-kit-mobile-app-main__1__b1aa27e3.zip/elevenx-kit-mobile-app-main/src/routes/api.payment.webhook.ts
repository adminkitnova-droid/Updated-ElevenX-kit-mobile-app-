import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "node:crypto";
import { adminDb } from "@/lib/firebase-admin.server";

function isValidSignature(raw: string, signature: string | null) {
  if (!signature || !process.env.RELWORX_WEBHOOK_SECRET) return false;
  const expected = createHmac("sha256", process.env.RELWORX_WEBHOOK_SECRET).update(raw).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && timingSafeEqual(a, b);
}

export const Route = createFileRoute("/api/payment/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const raw = await request.text();
        if (!isValidSignature(raw, request.headers.get("Relworx-Signature"))) {
          return new Response("Invalid signature", { status: 401 });
        }
        const event = JSON.parse(raw) as Record<string, unknown>;
        const reference = String(event.reference ?? event.transaction_reference ?? "unknown");
        const db = await adminDb();
        await db.collection("paymentEvents").doc(reference).set({ ...event, receivedAt: new Date().toISOString() }, { merge: true });
        return Response.json({ received: true });
      },
    },
  },
});
