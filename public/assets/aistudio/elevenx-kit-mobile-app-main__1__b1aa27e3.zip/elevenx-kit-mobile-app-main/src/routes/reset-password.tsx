import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Page } from "@/components/shell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password | ELEVENX" },
      { name: "description", content: "Choose a new password for your ELEVENX account." },
      { property: "og:title", content: "Reset password | ELEVENX" },
      { property: "og:description", content: "Choose a new password for your ELEVENX account." },
    ],
  }),
  component: Reset,
});

function Reset() {
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password });
    if (error) { toast.error(error.message); return; }
    toast.success("Password updated"); navigate({ to: "/profile" });
  };
  return (
    <Page>
      <form className="panel mx-auto max-w-[420px]" onSubmit={save}>
        <h2 className="font-display text-2xl">New password</h2>
        <label className="field-label">New password</label>
        <input className="field" type="password" minLength={6} required autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button className="btn-gold full">SAVE PASSWORD</button>
      </form>
    </Page>
  );
}
