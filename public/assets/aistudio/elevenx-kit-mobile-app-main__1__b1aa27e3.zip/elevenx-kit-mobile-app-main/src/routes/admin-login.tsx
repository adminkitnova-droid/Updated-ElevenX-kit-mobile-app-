import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AuthForm } from "@/components/auth-form";
import { Page } from "@/components/shell";
import { homeFor, useAuth } from "@/lib/auth";

export const Route = createFileRoute("/admin-login")({
  head: () => ({
    meta: [
      { title: "Admin sign in | ELEVENX" },
      { name: "description", content: "Sign in to the ELEVENX admin dashboard." },
      { property: "og:title", content: "Admin sign in | ELEVENX" },
      { property: "og:description", content: "Sign in to the ELEVENX admin dashboard." },
    ],
  }),
  component: Login,
});

function Login() {
  const { user, roles, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && user) navigate({ to: homeFor(roles, "admin"), replace: true }); }, [user, roles, loading, navigate]);
  return <Page><AuthForm portal="admin" /></Page>;
}
