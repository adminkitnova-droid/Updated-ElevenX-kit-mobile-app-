import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AuthForm } from "@/components/auth-form";
import { Page } from "@/components/shell";
import { homeFor, useAuth } from "@/lib/auth";

export const Route = createFileRoute("/rider-login")({
  head: () => ({
    meta: [
      { title: "Rider sign in | ELEVENX" },
      { name: "description", content: "Sign in or apply to deliver for ELEVENX." },
      { property: "og:title", content: "Rider sign in | ELEVENX" },
      { property: "og:description", content: "Sign in or apply to deliver for ELEVENX." },
    ],
  }),
  component: Login,
});

function Login() {
  const { user, roles, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!loading && user) navigate({ to: homeFor(roles, "rider"), replace: true }); }, [user, roles, loading, navigate]);
  return <Page><AuthForm portal="rider" /></Page>;
}
