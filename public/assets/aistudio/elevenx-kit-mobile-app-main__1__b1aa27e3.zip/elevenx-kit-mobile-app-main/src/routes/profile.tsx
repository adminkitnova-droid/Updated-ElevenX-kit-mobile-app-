import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Bell, MapPin } from "lucide-react";
import { ProductImage } from "@/components/product-image";
import { Page } from "@/components/shell";
import { AccountSection } from "@/components/account-section";
import { money, useStore } from "@/lib/store";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "My Account | ELEVENX" },
      { name: "description", content: "Your profile, favourites, saved designs and orders." },
      { property: "og:title", content: "My Account | ELEVENX" },
      { property: "og:description", content: "Your profile, favourites, saved designs and orders." },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { update, products, favourites, savedDesigns, orders } = useStore();
  const navigate = useNavigate();
  const favProducts = products.filter((p) => favourites.includes(p.id));
  return (
    <Page>
      <div className="section-title">My Account</div>
      <AccountSection />
      <div className="section-title">My favourites</div>
      <div className="chips">
        {!favProducts.length && <span className="muted">No favourites yet.</span>}
        {favProducts.map((p) => <Link key={p.id} className="pill" to="/product/$id" params={{ id: String(p.id) }}>{p.name}</Link>)}
      </div>
      <div className="section-title">Saved Studio designs</div>
      {savedDesigns.map((d) => (
        <div key={d.id} className="panel">
          <b>{d.jersey} · {d.name || "Unnamed design"}</b>
          <p className="muted">Number {d.number} · {d.mode}</p>
          <button className="btn-outline" onClick={() => { update(() => ({ studio: d })); navigate({ to: "/studio" }); }}>EDIT DESIGN</button>
        </div>
      ))}
      <div className="section-title">My orders</div>
      {orders.map((o) => (
        <div key={o.id} className="panel"><b>{o.id}</b><p className="muted">{o.date} · {o.status} · Delivery: {o.deliveryStatus}</p><strong className="gold">{money(o.total)}</strong>{o.items?.map((it) => (
            <div key={it.productId + it.size} className="mt-2 flex items-center gap-2"><ProductImage src={it.image} alt={it.name} className="!w-[48px] shrink-0 rounded-md" /><small>{it.name} · {it.size} × {it.qty}</small></div>
          ))}</div>
      ))}
      {!orders.length && <div className="panel"><p className="muted">Your orders will appear here after checkout.</p></div>}
      <div className="section-title">Store & delivery portals</div>
      <div className="panel">
        <Link to="/admin-login" className="btn-outline full text-center">ADMIN SIGN IN</Link>
        <Link to="/rider-login" className="btn-outline full text-center">RIDER SIGN IN / APPLY</Link>
      </div>
      <div className="section-title">Support & information</div>
      <div className="panel space-y-2">
        <p className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Delivery coverage: Kampala and Wakiso</p>
        <p className="flex items-center gap-2"><Bell className="h-4 w-4 text-primary" /> Notifications: 2 demo updates</p>
        <p className="muted">ELEVENX demo prototype. Real payments are not connected yet.</p>
      </div>
    </Page>
  );
}
