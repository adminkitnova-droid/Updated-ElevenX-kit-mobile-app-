import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

type Profile = { full_name: string; phone: string; address: string; city: string; email: string | null };

/** Signed-in customer profile, saved to the account so it follows the customer across devices. */
export function AccountSection() {
  const { user, roles, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [p, setP] = useState<Profile | null>(null);

  useEffect(() => {
    if (!user) { setP(null); return; }
    supabase.from("profiles").select("full_name, phone, address, city, email").eq("id", user.id).maybeSingle()
      .then(({ data }) => setP(data ?? { full_name: "", phone: "", address: "", city: "Kampala", email: user.email ?? null }));
  }, [user]);

  if (loading) return <div className="panel animate-pulse h-24" />;
  if (!user) return (
    <div className="panel">
      <h2 className="text-lg font-bold">Sign in to your account</h2>
      <p className="muted mb-3">Save your details, delivery address and orders across devices.</p>
      <Link to="/auth" className="btn-gold inline-block">SIGN IN / REGISTER</Link>
    </div>
  );
  if (!p) return <div className="panel animate-pulse h-24" />;

  const save = async () => {
    const { error } = await supabase.from("profiles").update({ full_name: p.full_name, phone: p.phone, address: p.address, city: p.city }).eq("id", user.id);
    if (error) toast.error(error.message); else toast.success("Profile saved");
  };
  const set = (patch: Partial<Profile>) => setP({ ...p, ...patch });
  return (
    <>
      <div className="panel flex items-center gap-4">
        <div className="grid h-14 w-14 place-items-center rounded-full bg-primary text-2xl font-black text-primary-foreground">{(p.full_name || user.email || "E").charAt(0).toUpperCase()}</div>
        <div className="flex-1"><h2 className="text-lg font-bold">{p.full_name || "Customer"}</h2><p className="muted">{user.email}</p>
          {!!roles.length && <p className="gold text-xs">{roles.join(" · ")}</p>}</div>
        <button className="btn-outline" onClick={async () => { await signOut(); navigate({ to: "/auth", replace: true }); }}>SIGN OUT</button>
      </div>
      <div className="section-title">Personal information</div>
      <div className="panel">
        <label className="field-label">Full name</label><input className="field" value={p.full_name} onChange={(e) => set({ full_name: e.target.value })} />
        <label className="field-label">Phone</label><input className="field" value={p.phone} onChange={(e) => set({ phone: e.target.value })} />
        <label className="field-label">Delivery area</label>
        <select className="field" value={p.city} onChange={(e) => set({ city: e.target.value })}><option>Kampala</option><option>Wakiso</option></select>
        <label className="field-label">Delivery address</label><input className="field" value={p.address} placeholder="Area, street or landmark" onChange={(e) => set({ address: e.target.value })} />
        <button className="btn-gold" onClick={save}>SAVE PROFILE</button>
      </div>
    </>
  );
}
