import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Page } from "@/components/shell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

type App = { status: string; full_name: string; phone: string; area: string };

/** Shown to signed-in users who are not approved riders yet. */
export function RiderApplication() {
  const { user, refreshRoles } = useAuth();
  const [app, setApp] = useState<App | null | undefined>(undefined);
  const [form, setForm] = useState({ full_name: "", phone: "", area: "Kampala" });

  useEffect(() => {
    if (!user) return;
    supabase.from("rider_applications").select("status, full_name, phone, area").eq("user_id", user.id).maybeSingle().then(({ data }) => setApp(data));
  }, [user]);

  if (!user || app === undefined) return <Page><div className="panel h-32 animate-pulse" /></Page>;
  const apply = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("rider_applications").insert({ user_id: user.id, ...form });
    if (error) { toast.error(error.message); return; }
    toast.success("Application sent"); setApp({ status: "pending", ...form });
  };
  return (
    <Page>
      <div className="section-title">Rider Portal</div>
      {app ? (
        <div className="panel">
          <h2 className="text-lg font-bold">Application {app.status}</h2>
          <p className="muted">{app.full_name} · {app.phone} · {app.area}</p>
          <p className="muted mt-2">{app.status === "pending" ? "An admin will review your application. You'll get access once approved." : app.status === "rejected" ? "Your application was not approved. Contact the store for details." : "Approved — refresh to open your deliveries."}</p>
          {app.status === "approved" && <button className="btn-gold mt-2" onClick={() => refreshRoles()}>OPEN MY DELIVERIES</button>}
        </div>
      ) : (
        <form className="panel" onSubmit={apply}>
          <h2 className="text-lg font-bold">Apply to become a rider</h2>
          <label className="field-label">Full name</label><input className="field" required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          <label className="field-label">Phone</label><input className="field" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <label className="field-label">Service area</label>
          <select className="field" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })}><option>Kampala</option><option>Wakiso</option></select>
          <button className="btn-gold full">SUBMIT APPLICATION</button>
        </form>
      )}
    </Page>
  );
}
