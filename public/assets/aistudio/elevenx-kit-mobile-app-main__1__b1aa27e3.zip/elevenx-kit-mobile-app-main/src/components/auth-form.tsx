import { useState } from "react";
import { toast } from "sonner";
import { GoogleAuthProvider, createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup, updateProfile } from "firebase/auth";
import { getFirebaseAuth } from "@/lib/firebase";

type Portal = "customer" | "admin" | "rider";
const titles: Record<Portal, string> = { customer: "Customer account", admin: "Admin sign in", rider: "Rider portal" };

export function AuthForm({ portal, onSignedIn }: { portal: Portal; onSignedIn?: () => void }) {
  const canSignUp = portal !== "admin";
  const [mode, setMode] = useState<"in" | "up" | "forgot">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const auth = getFirebaseAuth();
    if (!auth) { toast.error("Firebase authentication is not configured"); return; }
    setBusy(true);
    try {
      if (mode === "forgot") {
        await sendPasswordResetEmail(auth, email);
        toast.success("Check your email for a reset link."); setMode("in");
      } else if (mode === "up") {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        if (name.trim()) await updateProfile(result.user, { displayName: name.trim() });
        onSignedIn?.(); setMode("in");
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        onSignedIn?.();
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message.replace("Firebase: ", "") : "Something went wrong");
    } finally { setBusy(false); }
  };

  const google = async () => {
    const auth = getFirebaseAuth();
    if (!auth) { toast.error("Firebase authentication is not configured"); return; }
    setBusy(true);
    try { await signInWithPopup(auth, new GoogleAuthProvider()); onSignedIn?.(); }
    catch (error) { toast.error(error instanceof Error ? error.message.replace("Firebase: ", "") : "Google sign-in failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="panel mx-auto max-w-[420px]">
      <h2 className="font-display text-2xl">{titles[portal]}</h2>
      <p className="muted mb-3">{mode === "up" ? "Create your account" : mode === "forgot" ? "Reset your password" : "Sign in to continue"}</p>
      {mode !== "forgot" && <><button type="button" className="btn-outline full" onClick={() => void google()} disabled={busy}>Continue with Google</button><p className="muted my-2 text-center text-xs">or use email</p></>}
      <form onSubmit={(event) => void submit(event)}>
        {mode === "up" && <><label className="field-label">Full name</label><input className="field" required value={name} onChange={(event) => setName(event.target.value)} /></>}
        <label className="field-label">Email</label><input className="field" type="email" required autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} />
        {mode !== "forgot" && <><label className="field-label">Password</label><input className="field" type="password" required minLength={6} autoComplete={mode === "up" ? "new-password" : "current-password"} value={password} onChange={(event) => setPassword(event.target.value)} /></>}
        <button className="btn-gold full" disabled={busy}>{busy ? "PLEASE WAIT…" : mode === "up" ? "CREATE ACCOUNT" : mode === "forgot" ? "SEND RESET LINK" : "SIGN IN"}</button>
      </form>
      <div className="mt-2 flex flex-wrap justify-between gap-2 text-xs">
        {mode !== "forgot" ? <button className="gold" onClick={() => setMode("forgot")}>Forgot password?</button> : <button className="gold" onClick={() => setMode("in")}>Back to sign in</button>}
        {canSignUp && mode === "in" && <button className="gold" onClick={() => setMode("up")}>{portal === "rider" ? "New rider? Create account" : "Create account"}</button>}
        {mode === "up" && <button className="gold" onClick={() => setMode("in")}>Have an account? Sign in</button>}
      </div>
      {portal === "admin" && <p className="muted mt-3 text-xs">Admin accounts are created by assigning an admin role to the Firebase user record.</p>}
    </div>
  );
}
