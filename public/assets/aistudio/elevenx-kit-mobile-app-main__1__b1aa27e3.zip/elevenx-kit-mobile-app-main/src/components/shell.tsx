import { Link, useLocation } from "@tanstack/react-router";
import { Crown, Heart, Home, Search, Shirt, ShoppingBag, User } from "lucide-react";
import type { ReactNode } from "react";
import { ProductImage } from "@/components/product-image";
import { money, useStore, type Product } from "@/lib/store";

export function TopBar() {
  const { cartCount } = useStore();
  return (
    <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-border bg-surface px-4">
      <Link to="/" className="flex items-center gap-2">
        <Crown className="h-7 w-7 text-primary" />
        <div>
          <b className="font-display text-2xl tracking-[2px]">ELEVEN<span className="text-primary">X</span></b>
          <small className="mt-0.5 block text-[8px] tracking-[1.3px] text-muted-foreground">YOUR GAME. YOUR STYLE. YOUR KIT.</small>
        </div>
      </Link>
      <div className="flex gap-4 text-primary">
        <Link to="/search" aria-label="Search"><Search className="h-6 w-6" /></Link>
        <Link to="/cart" aria-label="Cart" className="relative">
          <ShoppingBag className="h-6 w-6" />
          {cartCount > 0 && <CountBadge n={cartCount} />}
        </Link>
      </div>
    </header>
  );
}

function CountBadge({ n }: { n: number }) {
  return <span className="absolute -right-2 -top-1 rounded-full bg-primary px-1.5 text-[9px] font-bold text-primary-foreground">{n}</span>;
}

export function BottomNav() {
  const { cartCount } = useStore();
  const path = useLocation({ select: (l) => l.pathname });
  const items = [
    { to: "/", label: "HOME", icon: Home },
    { to: "/search", label: "SEARCH", icon: Search },
    { to: "/studio", label: "STUDIO", icon: Shirt, studio: true },
    { to: "/cart", label: "CART", icon: ShoppingBag, badge: cartCount },
    { to: "/profile", label: "PROFILE", icon: User },
  ] as const;
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 flex h-[67px] justify-around border-t border-border bg-surface pb-[env(safe-area-inset-bottom)]">
      {items.map((it) => {
        const Icon = it.icon;
        const current = path === it.to;
        const studio = "studio" in it;
        return (
          <Link key={it.to} to={it.to}
            className={`relative flex min-w-[17%] flex-col items-center justify-center gap-1 ${current ? "text-primary" : "text-muted-foreground"} ${studio ? "-translate-y-2 h-[58px] w-[58px] min-w-0 self-start rounded-2xl border border-gold-line bg-gold-soft" : ""}`}>
            <Icon className={studio ? "h-6 w-6" : "h-5 w-5"} />
            <small className="text-[9px] tracking-wide">{it.label}</small>
            {"badge" in it && it.badge > 0 && <CountBadge n={it.badge} />}
          </Link>
        );
      })}
    </nav>
  );
}

export function Page({ children }: { children: ReactNode }) {
  return <main className="mx-auto max-w-[1100px] px-4 pb-24 pt-4">{children}</main>;
}

export function ProductCard({ p }: { p: Product }) {
  const { favourites, toggleFav, addToCart } = useStore();
  const fav = favourites.includes(p.id);
  return (
    <article className="relative overflow-hidden rounded-[14px] border border-border bg-card pb-2.5">
      <button aria-label="Favourite" onClick={() => toggleFav(p.id)} className="absolute right-2 top-2 z-10 grid h-8 w-8 place-items-center rounded-full bg-background/85 text-primary">
        <Heart className="h-4 w-4" fill={fav ? "currentColor" : "none"} />
      </button>
      <Link to="/product/$id" params={{ id: String(p.id) }}>
        <ProductImage src={p.image} alt={p.name} />
        <div className="flex flex-col gap-1 p-2.5">
          <small className="text-primary">{p.team}</small>
          <b className="text-[13px]">{p.name}</b>
          <strong className="text-primary">{money(p.price)}</strong>
        </div>
      </Link>
      <button onClick={() => addToCart(p)} className="mx-2.5 rounded-lg bg-primary px-3 py-2 text-[11px] font-extrabold text-primary-foreground">ADD +</button>
    </article>
  );
}
