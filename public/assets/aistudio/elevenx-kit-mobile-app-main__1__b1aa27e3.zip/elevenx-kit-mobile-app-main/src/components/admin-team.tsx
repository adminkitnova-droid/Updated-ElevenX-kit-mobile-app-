import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

type Person = { id: string; email: string | null; full_name: string; phone: string; city: string; created_at: string };
type Application = { user_id: string; full_name: string; phone: string; area: string; status: string };
type RoleRow = { user_id: string; role: string };

/** Customers, rider approvals and admin accounts. Every change is re-checked by the database rules. */
export function AdminTeam({ view }: { view: "customers" | "applications" | "admins" }) {
  const { roles: myRoles, user } = useAuth();
  const superAdmin = myRoles.includes("super_admin");
  const [people, setPeople] = useState<Person[]>([]);
  const [apps, setApps] = useState<Application[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [p, a, r] = await Promise.all([
      supabase.from("profiles").select("id, email, full_name, phone, city, created_at").order("created_at", { ascending: false }),
      supabase.from("rider_applications").select("user_id, full_name, phone, area, status").order("created_at", { ascending: false }),
      supabase.from("user_roles").select("user_id, role"),
    ]);
    setPeople(p.data ?? []); setApps(a.data ?? []); setRoles(r.data ?? []); setLoading(false);
  }, []);
  useEffect(() => { void load(); }, [load]);

  const has = (id: string, role: string) => roles.some((r) => r.user_id === id && r.role === role);
  const run = async (p: PromiseLike<{ error: { message: string } | null }>, ok: string) => {
    const { error } = await p; if (error) toast.error(error.message); else { toast.success(ok); void load(); }
  };
  const decide = async (a: Application, approve: boolean) => {
    if (approve) {
      const { error } = await supabase.from("user_roles").insert({ user_id: a.user_id, role: "rider" });
      if (error && !error.message.includes("duplicate")) { toast.error(error.message); return; }
    }
    await run(supabase.from("rider_applications").update({ status: approve ? "approved" : "rejected" }).eq("user_id", a.user_id), approve ? "Rider approved" : "Application rejected");
  };

  if (loading) return <div className="panel h-24 animate-pulse" />;

  if (view === "applications") return (
    <>
      {!apps.length && <p className="muted">No rider applications yet.</p>}
      {apps.map((a) => (
        <div key={a.user_id} className="panel">
          <div className="section-row"><b>{a.full_name}</b><span className="pill">{a.status}</span></div>
          <p className="muted">{a.phone} · {a.area}</p>
          {a.status === "pending" && <div className="flex gap-2">
            <button className="btn-gold" onClick={() => decide(a, true)}>APPROVE</button>
            <button className="btn-outline" onClick={() => decide(a, false)}>REJECT</button>
          </div>}
          {a.status === "approved" && has(a.user_id, "rider") && <button className="btn-outline" onClick={() => run(supabase.from("user_roles").delete().eq("user_id", a.user_id).eq("role", "rider"), "Rider access removed")}>REMOVE RIDER ACCESS</button>}
        </div>
      ))}
    </>
  );

  if (view === "admins") return (
    <>
      {!superAdmin && <p className="muted">Only the super admin can add or remove administrators.</p>}
      {people.map((p) => (
        <div key={p.id} className="panel section-row">
          <div><b>{p.full_name || "—"}</b><p className="muted">{p.email}</p>
            <small className="gold">{has(p.id, "super_admin") ? "Super admin" : has(p.id, "admin") ? "Admin" : "Customer"}</small></div>
          {superAdmin && p.id !== user?.id && (has(p.id, "admin")
            ? <button className="btn-outline" onClick={() => run(supabase.from("user_roles").delete().eq("user_id", p.id).eq("role", "admin"), "Admin removed")}>REMOVE ADMIN</button>
            : <button className="btn-gold" onClick={() => run(supabase.from("user_roles").insert({ user_id: p.id, role: "admin" }), "Admin added")}>MAKE ADMIN</button>)}
        </div>
      ))}
    </>
  );

  return (
    <>
      <p className="muted">{people.length} registered accounts</p>
      {people.map((p) => (
        <div key={p.id} className="panel">
          <b>{p.full_name || "—"}</b><p className="muted">{p.email} · {p.phone || "no phone"} · {p.city}</p>
          <small className="muted">Joined {new Date(p.created_at).toLocaleDateString()}</small>
        </div>
      ))}
    </>
  );
}
