import { useState } from "react";
import { CircleMarker, MapContainer, Polyline, TileLayer, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";

type Point = { lat: number; lon: number; label: string };
type Props = { value: Point | null; onChange: (point: Point, route: { distanceKm: number; durationMin: number }) => void; rider?: Point | null };
const center: [number, number] = [0.3476, 32.5825];
const apiKey = import.meta.env.NEXT_PUBLIC_GEOAPIFY_API_KEY;

function DestinationPicker({ onPick }: { onPick: (lat: number, lon: number) => void }) {
  useMapEvents({ click: (event) => onPick(event.latlng.lat, event.latlng.lng) });
  return null;
}

export function GeoapifyDeliveryMap({ value, onChange, rider }: Props) {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [message, setMessage] = useState("");

  const selectPoint = async (lat: number, lon: number, label?: string) => {
    if (!apiKey) { setMessage("Geoapify is not configured"); return; }
    setSearching(true); setMessage("");
    try {
      const routeResponse = await fetch(`https://api.geoapify.com/v1/routing?waypoints=${lat},${lon}|0.3476,32.5825&mode=drive&apiKey=${apiKey}`);
      const route = await routeResponse.json();
      const summary = route.features?.[0]?.properties?.summary;
      const distanceKm = Number(summary?.distance ?? 0) / 1000;
      const durationMin = Number(summary?.time ?? 0) / 60;
      onChange({ lat, lon, label: label ?? `${lat.toFixed(5)}, ${lon.toFixed(5)}` }, { distanceKm, durationMin });
    } catch { setMessage("Could not calculate this route. Try another point."); }
    finally { setSearching(false); }
  };

  const search = async () => {
    if (!query.trim() || !apiKey) return;
    setSearching(true); setMessage("");
    try {
      const response = await fetch(`https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(query)}&limit=1&apiKey=${apiKey}`);
      const result = await response.json();
      const feature = result.features?.[0];
      if (!feature) { setMessage("Destination not found"); return; }
      await selectPoint(feature.geometry.coordinates[1], feature.geometry.coordinates[0], feature.properties.formatted);
    } catch { setMessage("Search failed. Try selecting the map directly."); }
    finally { setSearching(false); }
  };

  const destination: [number, number] | null = value ? [value.lat, value.lon] : null;
  const riderPoint: [number, number] | null = rider ? [rider.lat, rider.lon] : null;
  return <div className="space-y-2">
    <div className="flex gap-2"><input className="field" placeholder="Search destination" value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); void search(); } }} /><button type="button" className="btn-outline shrink-0" onClick={() => void search()} disabled={searching}>SEARCH</button></div>
    <div className="relative overflow-hidden rounded-2xl border border-border"><MapContainer center={center} zoom={12} scrollWheelZoom className="h-[260px] w-full"><TileLayer attribution='&copy; Geoapify &copy; OpenStreetMap contributors' url={`https://maps.geoapify.com/v1/tile/osm-bright-smooth/{z}/{x}/{y}.png?apiKey=${apiKey}`} /><DestinationPicker onPick={(lat, lon) => void selectPoint(lat, lon)} />{destination && <CircleMarker center={destination} radius={10} pathOptions={{ color: "#c9922e", fillColor: "#c9922e", fillOpacity: 0.9 }} />}{riderPoint && <CircleMarker center={riderPoint} radius={8} pathOptions={{ color: "#2e7d65", fillColor: "#2e7d65", fillOpacity: 0.9 }} />}{destination && riderPoint && <Polyline positions={[riderPoint, destination]} pathOptions={{ color: "#2e7d65", dashArray: "6 8" }} />}</MapContainer></div>
    {value && <p className="text-xs text-muted-foreground"><b>Destination:</b> {value.label}</p>}
    {message && <p className="text-xs text-destructive">{message}</p>}
  </div>;
}
