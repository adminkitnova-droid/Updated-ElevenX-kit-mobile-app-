import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Page } from "@/components/shell";
import { useAuth, type Role } from "@/lib/auth";

/** UI gate only — the database rules are what actually protect admin and rider data. */
export function PortalGate({ role, children, fallback }: { role: Role; children: ReactNode; fallback?: ReactNode }) {
  const { user, roles, loading } = useAuth();
  const login = role === "rider" ? "/rider-login" : "/admin-login";
  if (loading) return <Page><div className="panel h-32 animate-pulse" /></Page>;
  if (!user) return (
    <Page><div className="panel mx-auto max-w-[420px]">
      <h2 className="font-display text-2xl">Sign in required</h2>
      <p className="muted mb-3">This area is for {role === "rider" ? "approved riders" : "store administrators"} only.</p>
      <Link to={login} className="btn-gold inline-block">SIGN IN</Link>
    </div></Page>
  );
  if (!roles.includes(role)) return <>{fallback ?? (
    <Page><div className="panel mx-auto max-w-[420px]">
      <h2 className="font-display text-2xl">No access</h2>
      <p className="muted mb-3">Your account ({user.email}) doesn't have {role} access. Ask the super admin to grant it.</p>
      <Link to="/profile" className="btn-outline inline-block">GO TO MY ACCOUNT</Link>
    </div></Page>
  )}</>;
  return <>{children}</>;
}
