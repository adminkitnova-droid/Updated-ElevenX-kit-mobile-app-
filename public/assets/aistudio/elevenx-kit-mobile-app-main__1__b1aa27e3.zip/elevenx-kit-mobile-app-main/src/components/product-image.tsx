import { useEffect, useRef, useState } from "react";
import { Shirt } from "lucide-react";
import { cn } from "@/lib/utils";
import { resolveImage, resolveImageSync } from "@/lib/images";

/** One shared jersey photo renderer: fixed 4:5 ratio, loading shimmer, fallback when the photo fails. `src` is a product image ref. */
export function ProductImage({ src: ref, alt, className }: { src?: string; alt: string; className?: string }) {
  const sync = resolveImageSync(ref);
  const [src, setSrc] = useState<string | undefined>(sync ?? undefined);
  const [state, setState] = useState<"loading" | "ok" | "error">(ref ? "loading" : "error");
  const img = useRef<HTMLImageElement>(null);

  useEffect(() => {
    let live = true;
    if (!ref) { setState("error"); return; }
    if (sync !== null) setSrc(sync); else setState("loading");
    resolveImage(ref).then((u) => { if (!live) return; if (u) setSrc(u); else setState("error"); });
    return () => { live = false; };
  }, [ref, sync]);

  useEffect(() => {
    const el = img.current;
    if (!src) return;
    // Photo may finish loading before the page becomes interactive.
    if (el?.complete) setState(el.naturalWidth ? "ok" : "error"); else setState("loading");
  }, [src]);

  return (
    <div className={cn("relative aspect-[4/5] w-full overflow-hidden bg-muted", className)}>
      {state === "loading" && <div className="absolute inset-0 animate-pulse bg-accent" aria-hidden />}
      {state === "error" ? (
        <div role="img" aria-label={alt} className="absolute inset-0 grid place-items-center text-muted-foreground">
          <div className="flex flex-col items-center gap-1"><Shirt className="h-8 w-8" /><small className="text-[10px]">Photo unavailable</small></div>
        </div>
      ) : src ? (
        <img ref={img} src={src} alt={alt} loading="lazy" decoding="async"
          onLoad={() => setState("ok")} onError={() => setState("error")}
          className={cn("absolute inset-0 h-full w-full object-cover transition-opacity", state === "ok" ? "opacity-100" : "opacity-0")} />
      ) : null}
    </div>
  );
}
