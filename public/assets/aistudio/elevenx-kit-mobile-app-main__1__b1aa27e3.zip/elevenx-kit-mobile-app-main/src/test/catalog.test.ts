import { describe, expect, it } from "vitest";
import { filterProducts } from "@/lib/catalog";
import { cartTotals, money, type Product } from "@/lib/store";

const p = (id: number, category: string, price: number, name = `P${id}`): Product => ({ id, name, team: name, category, price, size: ["M"], stock: 1, image: "" });
const list = [p(1, "Club", 85000, "Arsenal"), p(2, "National", 75000, "Uganda Cranes"), p(3, "Club", 95000, "Real Madrid")];

describe("catalog", () => {
  it("filters by category", () => expect(filterProducts(list, "", "National", "popular").map((x) => x.id)).toEqual([2]));
  it("searches team case-insensitively", () => expect(filterProducts(list, "uganda", "All", "popular").map((x) => x.id)).toEqual([2]));
  it("sorts high to low", () => expect(filterProducts(list, "", "All", "high").map((x) => x.id)).toEqual([3, 1, 2]));
  it("totals the cart", () => expect(cartTotals([{ product: list[0]!, qty: 2, size: "M", image: "" }])).toEqual({ count: 2, total: 170000 }));
  it("formats UGX", () => expect(money(85000)).toBe("UGX 85,000"));
});
