<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- ELEVENX shop state lives in src/lib/store.tsx (React context persisted to browser localStorage key "elevenx-demo"); the source app had no backend, so move to Lovable Cloud only when sign-in or shared data is added.
- Accounts use Lovable Cloud auth; roles live in public.user_roles (super_admin/admin/rider) checked via has_role in RLS — UI gates (PortalGate) are cosmetic, database rules are the security boundary.
